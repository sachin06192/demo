export const defaultOptions = {
	age: 0,
	collegeName: "",
	institutionID: 0,
	annualGrowthRate: 0.08,
	annualInflation: 0.06,
	collegeDuration: 4,
	collegeStartAge: 18,
	collegeStartYear: 2036,
	currentAnnualCost: 0,
	initialInvestment: 0,
	percentToCover: 1,
	contributionType: "Monthly",
	contributionAmount: 0,
	includeContributionIncrease: false,
	stepAmount: 0,
	stepStartDate: "2018.1",
	imageWidth: 306
}

export const defaultOptionsWithoutCollege = {
	age: 0,
	annualGrowthRate: 0.06,
	collegeDuration: 4,
	collegeStartAge: 18,
	collegeStartYear: 2036,
	contributionType: "Monthly",
	contributionAmount: 0,
	includeContributionIncrease: true,
	stepAmount: 0,
	stepStartDate: "2018.1",
	imageWidth: 306
}

export const getQucikResults = function(options, callback) {
	return  $.post("/advisor/investments//cscapi/getquickresults",options,
			  	function(data, status){
			  		
			  		if(status === "success")
			  		{
			  			if(typeof callback === "function") callback(data)
			  		}
			  		
			 })
}
