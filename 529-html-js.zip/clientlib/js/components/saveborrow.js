// import noUiSlider from "nouislider"
(function(w) {
  'use strict'


  let SaveBorrow = function() {
    this.section = select('#save-borrow-section')
    this.slider = select('#saving-slider')
    this.userAmtTotalInput = select('#user-amt-total')
    this.userAmtPerMonthInput = select('#user-amt-pay-per-month')
    this.userAmt = parseInt(this.userAmtTotalInput.value)
    this.userAmtPerMonth = parseInt(this.userAmtPerMonthInput.value)

    //this.savePriceVal = null
    //this.borrowPriceVal = null
    //this.borrowPrice = 36000
    //this.savePrice = this.userAmtPerMonthInput.value
    this.priceDiffer = this.borrowPrice - this.savePrice
    this.init()
  }

  SaveBorrow.prototype = {
    init() {
      this.moneyFormat()
      this.perMonthUpdate()
      this.initSlider()
      this.userAmtTotalInputListener()
      this.userAmtPerMonthInputListener()


    },

    moneyFormat() {
	    Number.prototype.formatMoney = function(c, d, t) {
	      var n = this,
	        c = isNaN(c = Math.abs(c)) ? 2 : c,
	        d = d == undefined ? "." : d,
	        t = t == undefined ? "," : t,
	        s = n < 0 ? "-" : "",
	        i = String(parseInt(n = Math.abs(Number(n) || 0).toFixed(c))),
	        j = (j = i.length) > 3 ? j % 3 : 0;
	      return s + '$ ' + (j ? i.substr(0, j) + t : "") + i.substr(j).replace(/(\d{3})(?=\d)/g, "$1" + t) + (c ? d + Math.abs(n - i).toFixed(c).slice(2) : "");
	    }
	},

    toolTipFormatter(v) {

      let toolTipWrapper = "<div class='custom-tool-tip-wrapper'>" +
        "<div class='tool-tip-header'>" +
        "<span class='text-secondary'>The difference you pay if you borrow:</span> <span class='display-4 text-black ml-2 bold-md mb-0'>" + (this.borrowPrice(v) - this.savePrice(v)).formatMoney(0) + "</span>" +
        "</div>" +
        "<div class='tool-tip-body'>" +
        "<div class='tool-tip-row'>" +
        "<div class='tool-tip-body-col'>" +
        "<p class='text-secondary'>Save (invest)</p><span class='display-4 bold-md'>" + this.savePrice(v).formatMoney(0) + "</span>" +
        "</div>" +
        "<div class='tool-tip-body-col text-secondary'>or</div>" +
        "<div class='tool-tip-body-col'>" +
        "<p class='text-secondary'>Borrow (you pay)</p><span class='display-4 bold-md'>" + this.borrowPrice(v).formatMoney(0) + "</span>" +
        "</div>" +
        "</div></div>" +
        "<div class='tool-tip-footer'><strong>" + Math.round(v) + " Years" + "</strong></div>"

      return toolTipWrapper
    },

    initSlider() {

      noUiSlider.create(this.slider, {
        start: [0],
        connect: true,
        step: 1,
        range: {
          'min': 0,
          'max': 18
        },
        tooltips: [{ to: (v) => this.toolTipFormatter(v) }]
      })

      let offset = select('.custom-tool-tip-wrapper').scrollHeight
      this.slider.style.marginTop = 250 + "px"
    },

    userAmtPerMonthInputListener() {
      this.userAmtPerMonthInput.addEventListener('input', () => {
        this.userAmtPerMonth = parseInt(this.userAmtPerMonthInput.value)
        this.totalAmtUpdate()
        this.updateSlider()
      })
    },

    userAmtTotalInputListener() {
      this.userAmtTotalInput.addEventListener('input', () => {
        this.userAmt = parseInt(this.userAmtTotalInput.value)
        this.perMonthUpdate()
        this.updateSlider()
      })
    },

    totalAmtUpdate() {
      let perMonthVal = this.userAmtPerMonth,
        totalVal = this.calculateSavings(perMonthVal, 18)
      this.userAmt = Math.floor(totalVal)
      this.userAmtTotalInput.value = Math.floor(totalVal)
    },

    perMonthUpdate() {
      let totalVal = this.userAmt,
        perMonthValue = this.calculateMonthlySavingsInstallment(totalVal, 18)
      this.userAmtPerMonth = Math.floor(perMonthValue)
      this.userAmtPerMonthInput.value = Math.floor(perMonthValue)
    },

    updateSlider() {
      this.slider.noUiSlider.destroy()
      this.initSlider()
    },
    calculateMonthlySavingsInstallment(amount, yrs) {
      return amount * .005 / (Math.pow((1 + 0.005), (12 * yrs)) - 1);
    },
    calculateMonthlyBorrowEMI(amount, yrs) {
      return amount * (.005 * (Math.pow((1 + .005), (12 * yrs)))) / (Math.pow((1 + .005), (12 * yrs)) - 1);
    },
    calculateSavings(amount, yrs) {
      return amount * (Math.pow((1 + 0.005), (12 * yrs)) - 1) / .005;
    },
    calculateLoan(emi, yrs) {
      return emi * (Math.pow((1 + .005), (12 * yrs)) - 1) / (.005 * (Math.pow((1 + .005), (12 * yrs))));
    },

    borrowPrice(year) {
      return Math.ceil(this.calculateMonthlyBorrowEMI(this.userAmt, 18) * 12 * year)
      //return Math.round(this.userAmtPerMonth * 12 * year || this.userAmtPerMonth)
    },

    savePrice(year) {
      let val = Math.floor(this.calculateSavings(this.calculateMonthlySavingsInstallment(this.userAmt, 18), year))
      
      return val
    }
  }

  function select(s) {
    return document.querySelector(s)
  }

  if (select('#save-borrow-section')) new SaveBorrow()
  

})(window)
