// smoth scroll

(function($) {
    $.fn.arctic_scroll = function(options) {
        var defaults = {
            elem: $(this),
            speed: 500,
            scroll_selector: 'html,body'
        };
        var options = $.extend(defaults, options),
            to_scroll = options.scroll_selector;
        options.elem.click(function(event) {
            event.preventDefault();
            var offset = $(this).attr('data-offset') ? $(this).attr('data-offset') : !1,
                position = $(this).attr('data-position') ? $(this).attr('data-position') : !1;
            if (offset) {
                var toMove = parseInt(offset);
                $(options.scroll_selector).stop(!0, !1).animate({
                    scrollTop: $(this.hash).offset().top + toMove
                }, options.speed)
            } else if (position) {
                var toMove = parseInt(position);
                $(options.scroll_selector).stop(!0, !1).animate({
                    scrollTop: toMove
                }, options.speed)
            } else {
                console.log($(this.hash))
                $(options.scroll_selector).stop(!0, !1).animate({
                    scrollTop: $(this.hash).offset().top
                }, options.speed)
            }
        })
    }
})(jQuery);
$(function() {
    $(".demoScroll").arctic_scroll({
        speed: 800
    })
});
(function($, window, document, undefined) {
    $.fn.extend({
        scrollspy: function(options) {
            var defaults = {
                namespace: 'scrollspy',
                activeClass: 'active',
                animate: !0,
                offset: 0,
                container: window
            };
            options = $.extend({}, defaults, options);
            var add = function(ex1, ex2) {
                return parseInt(ex1, 10) + parseInt(ex2, 10)
            }
            var findElements = function(links) {
                var elements = [];
                for (var i = 0; i < links.length; i++) {
                    var link = links[i];
                    var hash = $(link).attr("href");
                    var element = $(hash);
                    if (element.length > 0) {
                        var top = Math.floor(element.offset().top),
                            bottom = top + Math.floor(element.outerHeight());
                        elements.push({
                            element: element,
                            hash: hash,
                            top: top,
                            bottom: bottom
                        })
                    }
                }
                return elements
            };
            var findLink = function(links, hash) {
                for (var i = 0; i < links.length; i++) {
                    var link = $(links[i]);
                    if (link.attr("href") === hash) {
                        return link
                    }
                }
            };
            var resetClasses = function(links) {
                for (var i = 0; i < links.length; i++) {
                    var link = $(links[i]);
                    link.parent().removeClass(options.activeClass)
                }
            };
            return this.each(function() {
                var element = this,
                    container = $(options.container);
                var links = $(element).find('a');
                for (var i = 0; i < links.length; i++) {
                    var link = links[i];
                    $(link).on("click", function(e) {
                        var target = $(this).attr("href"),
                            $target = $(target);
                        if ($target.length > 0) {
                            var top = add($target.offset().top, options.offset);
                            if (options.animate) {
                                $('html, body').animate({
                                    scrollTop: top
                                }, 1000)
                            } else {
                                window.scrollTo(0, top)
                            }
                            e.preventDefault()
                        }
                    })
                }
                var elements = findElements(links);
                container.bind('scroll.' + options.namespace, function() {
                    var position = {
                        top: add($(this).scrollTop(), Math.abs(options.offset)),
                        left: $(this).scrollLeft()
                    };
                    var link;
                    for (var i = 0; i < elements.length; i++) {
                        var current = elements[i];
                        if (position.top >= current.top && position.top < current.bottom) {
                            var hash = current.hash;
                            link = findLink(links, hash);
                            if (link) {
                                if (options.onChange) {
                                    options.onChange(current.element, $(element), position)
                                }
                                resetClasses(links);
                                link.parent().addClass(options.activeClass);
                                break
                            }
                        }
                    }
                    if (!link && options.onExit) {
                        options.onExit($(element), position)
                    }
                })
            })
        }
    })
})(jQuery, window, document, undefined);
$("#nav1").scrollspy({
    offset: -75
})