// ; (function () {

//     var savingRangeSlider = document.getElementById('saving-rangeSlider');

//     if (savingRangeSlider) {
//         noUiSlider.create(savingRangeSlider, {
//             start: 0,
//             tooltips: true,
//             range: {
//                 'min': 0,
//                 'max': 18
//             },
//             pips: {
//                 mode: 'range',
//                 // values: [0, 9, 18],
//                 density: 9,
//                 format: wNumb({
//                     decimals: 0,
//                     prefix: 'years'
//                 })
//             }
//         });
//     }
// })();