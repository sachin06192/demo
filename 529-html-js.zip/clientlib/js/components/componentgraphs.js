let graphAconsts = {
  chart: {
    type: 'areaspline'
  },
  title: {
    text: ''
  },
  xAxis: {
    lineWidth: 1,
    lineColor: '#000',
    tickLength: 0,
    crosshair: {
      enabled: true
    },
    categories: [
      '0',
      '5',
      '10',
      '18'
    ]
  },
  yAxis: {
    // title: {
    //   tickWidth: 0
    // }
    tickWidth: 0,
    //crosshair: false,
    lineWidth: 1,
    lineColor: '#000',
    gridLineWidth: 0,
    labels: {
      enabled: false
    },
    opposite: true
  },
  tooltip: {
    shared: false,
    followPointer: false,
    valueSuffix: '$',
    useHTML: true,
  },
  plotOptions: {
    areaspline: {
      color: '#005f9e',
      fillOpacity: 0.5,
      lineWidth: 1,
      lineColor: '#005f9e',
      stickyTracking: false,
      fillColor: {
        linearGradient: {
          x1: 0,
          y1: 0,
          x2: 0,
          y2: 1
        },
        stops: [
          [0, '#97c5f0'],
          [1, 'rgba(151, 197, 240, 0.2)']
        ]
      }
    }
  },
  credits: {
    enabled: false
  },
  series: [{
    name: '1st child',
    data: [0, 11500, 28000,  41243]
  }, {
    name: '2nd child',
    data: [0, 25656, 42555, 63739]
  }]
};

if (document.querySelector('#graph-item-1')) {
  Highcharts.chart(document.querySelector('#graph-item-1'), graphAconsts)
}