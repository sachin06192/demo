$(function () {

	// Modal open
	$(document).on('click', '.cg-modalToggle', function (e) {
		e.preventDefault();
		let targetModalId = $(this).attr('modal-target');
		CGModal.show(targetModalId);
	});

	// Modal close on click of close button
	$(document).on('click', '.cg-modal-close', function () {
		$(this).closest('.cg-modal').removeClass('show');
	});

	// Modal close on click of body
	$(document).on('click', function (e) {
		let openedModalId = $('.cg-modal.show').attr('id');
		let openedModal = document.getElementById(openedModalId);
		// console.log(openedModalId)
		if (e.target == openedModal) {
			// console.log('close modal')
			$("#" + openedModalId).removeClass('show');
		}
	});

});

let CGModal = {
	show: function (id) {
		$(id).addClass('show');
	},
	hide: function (id) {
		$(id).removeClass('show');
	}
}
