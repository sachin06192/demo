// Selectable table
$('.selectable-table .cg-table-list').on('click', function () {
    $('.selectable-table .cg-table-list').removeClass('selected');
    $(this).addClass('selected');
    let group_checkbox = "input:checkbox[name='" + $(this).find('input').attr("name") + "']";
    $(group_checkbox).prop("checked", false);
    $(this).find('input').prop("checked", true);
});