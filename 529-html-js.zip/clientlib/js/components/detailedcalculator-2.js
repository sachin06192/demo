/* Detailed calculator */
import { defaultOptions, getQucikResults } from "./getquickresults"


(function(window) {
  'use strict'
  let DCObject = ''
  //resultOptions = defaultOptions
  function DetailedCalculator() {
    this.$detailedCalculator = $('#main-detailed-calculator-b')
    this.$nextBtn = this.$detailedCalculator.find('.next')
    this.$prevBtn = this.$detailedCalculator.find('.previous')
    this.$nextBtnInner = this.$detailedCalculator.find('.inner-next')
    this.$prevBtnInner = this.$detailedCalculator.find('.inner-previous')
    this.$progressBarLi = this.$detailedCalculator.find('.progressbar li')
    this.$genderOption = this.$detailedCalculator.find('[name="genderOption"]')
    this.$collegeCategoryChangeButton = this.$detailedCalculator.find('[name="college-category-chooser"]')
    this.$collegeDurationOption = this.$detailedCalculator.find('[name="college-duration"]')
    this.$ageOption = this.$detailedCalculator.find('[name="student-age"]')
    this.$savingsPercentageOption = this.$detailedCalculator.find('[name="savings-percentage-option"]')
    this.$additionalExpenseChooser = this.$detailedCalculator.find('[name="additional-expense-chooser"]')
    this.$savingsPercentageSpan = this.$detailedCalculator.find('.savings-percentage-span')
    this.$collegeOption = this.$detailedCalculator.find('#college-option')
    this.$idealSavingSpan = this.$detailedCalculator.find('.ideal-savings-amount')
    this.$savingsTotalMonthlySpan = this.$detailedCalculator.find('#savings-total-monthly')
    this.$houseHoldInput = this.$detailedCalculator.find('#house-hold-input')
    this.$monthlyExpenseInput = this.$detailedCalculator.find('#monthly-expense-input')
    this.$monthlyContributionInput = this.$detailedCalculator.find('#monthly-contribution-input')
    this.$oneTimeInvestmentInput = this.$detailedCalculator.find('#one-time-investment-input')
    this.$monthlySaveSpan = this.$detailedCalculator.find('.monthly-save')
    this.$investChangerButton = this.$detailedCalculator.find('.invest-changer')
    this.$annualInflationOption = this.$detailedCalculator.find('#annual-inflation-option')
    this.$annualGrowthOption = this.$detailedCalculator.find('#annual-growth-option')
    this.$totalSavingsSpan = this.$detailedCalculator.find('.total-savings')
    this.$totalDeficitSpan = this.$detailedCalculator.find('.total-deficit')
    this.$monthlyContributionTotalSpan = this.$detailedCalculator.find('.monthly-contribution-total')
    this.$oneTimeInvestmentSpan = this.$detailedCalculator.find('.total-onetime-investment')
    this.$fundingTotalSpan = this.$detailedCalculator.find('.funding-total')
    this.$userEditTrigger = this.$detailedCalculator.find('.user-edit-trigger')
    this.$tabLinks = this.$detailedCalculator.find('.tab-link>a')
    this.$percentageToggler = this.$detailedCalculator.find('#percentage-toggler-wrapper')
    this.$percentageFullSpan = this.$detailedCalculator.find('#percentage-full-wrapper')
    this.$planBannerTitle = $('#plan-banner-title')
    this.$additionalControlSpan = this.$detailedCalculator.find('.addition-control-div')
    this.$bottomActions = this.$detailedCalculator.find('.bottom-action')
    this.$circleProgressHolder = this.$detailedCalculator.find('.circle-progress-holder')
    this.$totalCollegeCostSpan = this.$detailedCalculator.find('.total-college-cost')
    this.$additionalCostSpan = this.$detailedCalculator.find('.additional-cost')
    this.$inOutStateSpan = this.$detailedCalculator.find('.in-out-state')
    this.$universitySpan = this.$detailedCalculator.find('.university')
    this.$collegeStartYearSpan = this.$detailedCalculator.find('.college-start-year')
    this.$monthlyContributionMessageSpan = this.$detailedCalculator.find('.monthly-contribution-span')
    this.$bottomActions = this.$detailedCalculator.find('.bottom-action')
    this.$reviewPlanBtn = this.$detailedCalculator.find('.review-btn')
    this.$inflamationPercentSpan = this.$detailedCalculator.find('.inflamation-percent-span')
    this.$annualGrowthPercentSpan = this.$detailedCalculator.find('.annual-growth-percent-span')
    this.$infoYourGoal = this.$detailedCalculator.find('.info-box.your-goal')
    this.$infoYourNumber = this.$detailedCalculator.find('.info-box.your-number')
    this.$infoYourSummary = this.$detailedCalculator.find('.info-box.your-summary')
    this.$resetButton = this.$detailedCalculator.find('.reset-button')
    this.$totalCollegeTuitionCostSpan = this.$detailedCalculator.find('.total-college-tuition-cost')

    this.current_fs = null
    this.next_fs = null
    this.previous_fs = null
    this.savingsPartialPercentage = this.$savingsPercentageOption.val()

    this.formError = false
    // details
    this.gender = ""
    this.resultOptions = {
      age: 0,
      annualGrowthRate: this.$annualGrowthOption.val(),
      annualInflation: this.$annualInflationOption.val(),
      collegeDuration: this.$collegeDurationOption.val(),
      collegeStartAge: 18,
      collegeStartYear: new Date().getFullYear() + 18,
      currentAnnualCost: 0,
      collegeName: "",
      contributionType: "Monthly",
      contributionAmount: 0,
      initialInvestment: this.$oneTimeInvestmentInput.val(),
      institutionID: null,
      percentToCover: 1,
      includeContributionIncrease: false,
      stepAmount: 0,
      stepStartDate: "2018.1",
      imageWidth: 306
    }
    this.collegeInStateFees = 0
    this.collegeInStateFeesWithoutCost = 0
    this.collegeOutStateFees = 0
    this.collegeOutStateFeesWithoutCost = 0
    this.collegeCategory = this.$collegeCategoryChangeButton.val()
    this.additionalExpense = this.$additionalExpenseChooser.val()
    //this.monthlySave = 0,
    //this.userMonthlySave = 0,
    this.monthlyContributionAmount = this.$monthlyContributionInput.val()
    this.initialMonthlyContribution = 0
    this.monthlyContributionTotal = 0
    this.idealSavings = 0
    //this.savingsMonthlyValue = 0
    this.partialSavings = 0
    this.investment = "fully"
    this.totalSavings = 0
    this.totalDeficit = 0
    this.totalSavingsPercent = 0
    this.collegeTotalCost = 0
    this.collegeTotalCostWithoutExpenses = 0
    this.delayedApiCall = null

    this.showYourNumbersSummary = false
    this.showReviewSummary = false
    // Intitialize
    this._init()
  }

  DetailedCalculator.prototype = {
    _init() {
      DCObject = this
      this.$percentageToggler.hide()
      this._eventListeners()
      this._collegeSelect()
      this._circleProgressInit()
      //this._calculateMonthlySave()
      this.$bottomActions.hide()
      this._getNationalCollegeAverages()



    },
    // National college averages
    _getNationalCollegeAverages() {
      $.post("https://www.americanfunds.com/advisor/investments//cscapi/findschoolsfrompage", {
          Page: 0,
          IncludeRoomAndBoard: true,
          CurrentCollegeName: "2018 National Public Averages",
          SortDirection: "ascending",
          TableType: ""
        },
        function(data, status) {

          if (status === "success") {
            let colleges = DCObject.getCGCollegeData(data.html)
            
            DCObject.$detailedCalculator.find('#N-public-tuition-span').html(colleges[0].inStateWithoutCosts.formatMoney(0))
            DCObject.$detailedCalculator.find('#N-private-tuition-span').html(colleges[1].inStateWithoutCosts.formatMoney(0))
            DCObject.$detailedCalculator.find('#NIL-tuition-span').html(colleges[2].inStateWithoutCosts.formatMoney(0)) 
            DCObject.$detailedCalculator.find('#N-public-additional-cost-span').html((colleges[0].inStateWithCosts - colleges[0].inStateWithoutCosts).formatMoney(0))
            DCObject.$detailedCalculator.find('#N-private-additional-cost-span').html((colleges[1].inStateWithCosts - colleges[1].inStateWithoutCosts).formatMoney(0))
            DCObject.$detailedCalculator.find('#NIL-additional-cost-span').html((colleges[2].inStateWithCosts - colleges[2].inStateWithoutCosts).formatMoney(0)) 
            
          }

        })
    },
    // College select
    _collegeSelect(data) {
      //console.log(data)
      DCObject.$collegeOption.select2({
        language: {
            inputTooShort: function() {
              return 'Enter the school name';
            }
        },
        data: data || [],
        ajax: {
          url: 'https://www.americanfunds.com/advisor/investments//cscapi/findschoolsfrompage',
          dataType: 'json',
          delay: 250,
          method: "POST",
          data: function(params) {
            return {
              Name: params.term || "National", // search term
              Page: params.page || 0,
              IncludeRoomAndBoard: true,
              CurrentCollegeName: "2018 National Public Averages",
              SortDirection: "ascending",
              TableType: ""
            }
          },
          processResults: function(data, params) {
            params.page = params.page || 0;
            let currentPageNumber = $(data.html).find('.action-paging-button.selected').data('pagenumber')
            let lastPageNumber = $(data.html).find('.action-next-button').prev().data('pagenumber')

            return {
              results: DCObject.getCGCollegeData(data.html),
              pagination: {
                more: (params.page * 10) < 10 * lastPageNumber
              }
            };
          },
          cache: true
        },

        //placeholder: 'Searchy',
        escapeMarkup: function(markup) { return markup; }, // let our custom formatter work
        minimumInputLength: 1,
        templateResult: DCObject.formatRepo,
        templateSelection: DCObject.formatRepoSelection
      })

      
    },

    initialRequestForCollege() {
      var $initialCollegeRequest = $.ajax({
        url: 'https://www.americanfunds.com/advisor/investments//cscapi/findschoolsfrompage' ,
        dataType: 'json',
        delay: 250,
        method: "POST",
        data: {
          Name: "National",
          Page: 0,
          IncludeRoomAndBoard: true,
          CurrentCollegeName: "2018 National Public Averages",
          SortDirection: "ascending",
          TableType: ""
        }
      })

      $initialCollegeRequest.then((data) => {
        let colleges = this.getCGCollegeData(data.html),
        toSelectData = []

        for(let i=0; i<colleges.length; i++)
        {
          let college = {id: colleges[i].id, text: colleges[i].name}

          toSelectData.push(college)
        }

        DCObject._collegeSelect(toSelectData)
      })
    },

    formatRepo(repo) {
      if (repo.loading) {
        return "Searching...";
      }
      var markup = "<div class='select2-result-repository clearfix'>" +
        "<div class='select2-result-repository__meta'>" +
        "<div class='select2-result-repository__title'>" + repo.name + "</div></div></div>"

      return markup;
    },
    formatRepoSelection(repo) {
      //return repo.full_name || repo.text;
      DCObject.resultOptions.collegeName = repo.name
      DCObject.resultOptions.institutionID = repo.id.split('_')[1]
      DCObject.resultOptions.contributionAmount = 0
      if (DCObject.collegeCategory === "state-public") {
        if (DCObject.additionalExpense === 'yes') {
          DCObject.resultOptions.currentAnnualCost = repo.inStateWithCosts
        } else {
          DCObject.resultOptions.currentAnnualCost = repo.inStateWithoutCosts
        }
      } else if (DCObject.collegeCategory === "outofstate-public") {
        if (DCObject.additionalExpense === 'yes') {
          DCObject.resultOptions.currentAnnualCost = repo.outStateWithCosts
        } else {
          DCObject.resultOptions.currentAnnualCost = repo.outStateWithoutCosts
        }
      } else if (DCObject.collegeCategory === "private") {
        DCObject.resultOptions.currentAnnualCost = repo.inStateWithCosts
      }
      DCObject.collegeInStateFees = repo.inStateWithCosts
      DCObject.collegeInStateFeesWithoutCost = repo.inStateWithoutCosts
      DCObject.collegeOutStateFees = repo.outStateWithCosts
      DCObject.collegeOutStateFeesWithoutCost = repo.outStateWithoutCosts



      DCObject.callQuickResults(function(data) {
        if (DCObject.$additionalControlSpan.hasClass = "disabled") {
          DCObject.$additionalControlSpan.removeClass('disabled')
        }
        DCObject.updateMonthlyContribution(data)
        DCObject.$bottomActions.show()
      })

      //DCObject.idealSavings = repo.outStateWithCosts
      //DCObject.savingsMonthlyValue = DCObject.idealSavings / 48
      //DCObject.partialSavings = DCObject.idealSavings * parseInt(DCObject.savingsPartialPercentage) / 100

      //DCObject.updateHtml()
      return repo.name
    },
    getCGCollegeData(response) {
      // prepare HTMLs from the response so that its easier to grab the values
      //console.log(response)

      $('body').append('<div id="cg-jsonHolder" style="display:none"></div>');
      $('#cg-jsonHolder').append(response);
      $('#cg-jsonHolder tbody tr td:first-child p:first-child').addClass('cg-college-name');

      var colleges = [];
      $('#cg-jsonHolder tbody tr').each(function(i, elem) {
        colleges.push({
          id: $(elem).attr("id"),
          name: $(elem).find('.cg-college-name').text(),
          outStateWithCosts: Math.round($(elem).data('outstatewithcosts')),
          outStateWithoutCosts: Math.round($(elem).data('outstatewithoutcosts')),
          inStateWithCosts: Math.round($(elem).data('instatewithcosts')),
          inStateWithoutCosts: Math.round($(elem).data('instatewithoutcosts'))
        });
      });
      $('#cg-jsonHolder').remove(); // remove the markups once the job is done

      return colleges;
    },
    // Quick result
    callQuickResults(cbFunc, noSpread) {
      if (DCObject.resultOptions.collegeName === "") {
        return
      }
      this.$bottomActions.addClass('disabled')
      getQucikResults(DCObject.resultOptions, (data) => {
        if (typeof cbFunc === "function") {
          cbFunc(data)
        }
        if (noSpread) {
          DCObject.updateHtml()
          this.$bottomActions.removeClass('disabled')
          return
        }
        if (this.investment === "partially") {
          DCObject.idealSavings = data.chartData.TotalCostToFund
          //DCObject.totalSavingsPercent = DCObject.calcPercent(data.chartData.TotalCostToFund, data.chartData.TotalSavings)
          DCObject.totalSavingsPercent = DCObject.calcPercent(data.chartData.TotalCost, data.chartData.TotalSavings)
          //DCObject.totalDeficit = data.chartData.TotalCostToFund - data.chartData.TotalSavings
          DCObject.totalDeficit = data.chartData.TotalCost - data.chartData.TotalSavings
        } else {
          DCObject.idealSavings = data.chartData.TotalCost
          DCObject.totalSavingsPercent = DCObject.calcPercent(data.chartData.TotalCost, data.chartData.TotalSavings)
          DCObject.totalDeficit = data.chartData.TotalCost - data.chartData.TotalSavings

        }

        //DCObject.savingsMonthlyValue = data.chartData.RequiredContribution
        DCObject.totalSavings = data.chartData.TotalSavings

        if (DCObject.additionalExpense === "yes") {
          DCObject.collegeTotalCost = data.chartData.TotalCost
          DCObject.collegeTotalCostWithoutExpenses = 0

        } else {
          DCObject.collegeTotalCostWithoutExpenses = data.chartData.TotalCost
          DCObject.collegeTotalCost = 0
        }



        DCObject.updateHtml()
        this.$bottomActions.removeClass('disabled')
      })

    },

    // Utilities
    calcPercent(num, per) {
      return (per / num) * 100
    },
    // validators
    validate() {
      return DCObject.collegeName !== ""
    },
    onlyNumber(evt) {
      evt = (evt) ? evt : window.event;
      var charCode = (evt.which) ? evt.which : evt.keyCode;
      if (charCode > 31 && (charCode < 48 || charCode > 57)) {
        return false;
      }
      return true;
    },
    // Calculations
    calculateTax(num) {
      return (num <= 13350) ? num * .1 :
        (num <= 50800) ? (13350 * .1) + (num - 13350) * .15 :
        (num <= 131200) ? (13350 * .1) + (50800 - 13350) * .15 + (num - 50800) * .25 :
        (num <= 212500) ? (13350 * .1) + (50800 - 13350) * .15 + (131200 - 50800) * .25 +
        (num - 131200) * .28 :
        (num <= 416700) ? (13350 * .1) + (50800 - 13350) * .15 + (131200 - 50800) * .25 +
        (212500 - 131200) * .28 + (num - 212500) * .33 :
        (num <= 444550) ? (13350 * .1) + (50800 - 13350) * .15 + (131200 - 50800) * .25 +
        (212500 - 131200) * .28 + (416700 - 212500) * .33 + (num - 416700) * .35 :
        (13350 * .1) + (50800 - 13350) * .15 + (131200 - 50800) * .25 + (212500 - 131200) * .28 +
        (416700 - 212500) * .33 + (444550 - 416700) * .35 + (num - 444550) * .396;
    },
    // calcSemester
    calcSemester(totalCollegeCost, totalSavings, collegeDuration) {
      var temp = Math.floor(collegeDuration*2*totalSavings/totalCollegeCost)
      return temp === 0 ? false : temp
    },
    // _calculateMonthlySave(){
    //   if(DCObject.resultOptions.collegeName === ""){
    //     return
    //   } 
    //   let houseHoldVal = this.$houseHoldInput.val(),
    //       monthlyExpenseVal = this.$monthlyExpenseInput.val(),
    //       monthlySaveValue = null

    //       monthlySaveValue = (((houseHoldVal - DCObject.calculateTax(houseHoldVal)) - (monthlyExpenseVal * 12)) * .6)/12
    //       DCObject.userMonthlySave = monthlySaveValue || 0
    //       DCObject.resultOptions.contributionAmount = Math.round(DCObject.userMonthlySave)

    // },
    _calculateMonthlySave() {
      if (DCObject.resultOptions.collegeName === "") {
        return
      }
      DCObject.resultOptions.contributionAmount = DCObject.monthlyContributionAmount
    },
    _animateBannerText(target) {
      let currentTitle = DCObject.$planBannerTitle.find('>.title.active'),
        activeTitle = DCObject.$planBannerTitle.find('>.title[data-relate=' + target + ']')

      currentTitle.removeClass('active')
      activeTitle.addClass('active')

      let tl = new TimelineLite()
      tl.staggerTo($(currentTitle).find('>span'), 0.4, { y: -40, autoAlpha: 0 }, 0.1)
        .to(currentTitle, 0.4, { autoAlpha: 0, display: 'none' })
        .to(activeTitle, 0.4, { autoAlpha: 1, display: 'block', overwrite: 'all' }, 'reveal')
        .staggerFromTo(activeTitle.find('>span'), 0.4, { y: 40, autoAlpha: 0, overwrite: 'all' }, { y: 0, autoAlpha: 1, overwrite: 'all' }, 0.1, 'reveal')

    },
    // Updation
    updateHtml() {
      DCObject.updateCircleProgress()
      DCObject.updateCollegeCostRelatedHtmls()
      DCObject.infoHtmlUpdates()
      DCObject.topBoxInfoHtmlUpdates()
      DCObject.$idealSavingSpan.html(DCObject.idealSavings.formatMoney(0))
      //DCObject.$savingsTotalMonthlySpan.html(DCObject.savingsMonthlyValue.formatMoney(0))
      let deficit = DCObject.totalDeficit

      if (DCObject.investment === "partially") {
        DCObject.$savingsPercentageSpan.html(DCObject.savingsPartialPercentage + '%')
      } else {
        DCObject.$savingsPercentageSpan.html('100%')
      }

      deficit = deficit <= 0 ? deficit * -1 : deficit

      DCObject.$totalSavingsSpan.html(DCObject.totalSavings.formatMoney(0))
      DCObject.$totalDeficitSpan.html(deficit.formatMoney(0))



      if (DCObject.totalDeficit > 0) {
        $('.progress-info .total-deficit').removeClass('text-success')
        $('.progress-info .total-deficit').addClass('text-danger')
        DCObject.$detailedCalculator.find('.surplus-gap-title').html('Gap')
        DCObject.$detailedCalculator.find('.total-deficit-summary').html(DCObject.totalDeficit.formatMoney(0))
      } else {
        $('.progress-info .total-deficit').removeClass('text-danger')
        $('.progress-info .total-deficit').addClass('text-success')
        DCObject.$detailedCalculator.find('.surplus-gap-title').html('Surplus')
        DCObject.$detailedCalculator.find('.total-deficit-summary').html('$0')
      }
      DCObject.$fundingTotalSpan.html(DCObject.totalDeficit.formatMoney(0))
      DCObject.$monthlyContributionTotalSpan.html(parseInt(DCObject.monthlyContributionAmount).formatMoney(0))
      DCObject.$oneTimeInvestmentSpan.html(parseInt(DCObject.resultOptions.initialInvestment).formatMoney(0))
      DCObject.$inflamationPercentSpan.html(DCObject.resultOptions.annualInflation * 100 + '%')
      DCObject.$annualGrowthPercentSpan.html(DCObject.resultOptions.annualGrowthRate * 100 + '%')
      DCObject.$detailedCalculator.find('.college-start-differ').html(18 - DCObject.resultOptions.age)

      if (DCObject.collegeCategory === "state-public") {
        DCObject.$inOutStateSpan.html('in state')
      } else if (DCObject.collegeCategory === "outofstate-public") {
        DCObject.$inOutStateSpan.html('out of state')
      }



    },
    updateCircleProgress() {
      let progressHolder = this.$circleProgressHolder,
        progressValue = progressHolder.find('.progress-value'),
        progressOverlay = progressHolder.find('.progress-circular__overlay')

      this.totalSavingsPercent = this.totalSavingsPercent > 100 ? 100 : Math.floor(this.totalSavingsPercent)
      progressValue.html(this.totalSavingsPercent + '%')
      TweenLite.to(progressOverlay, 0.5, { drawSVG: `0% ${this.totalSavingsPercent - 2}%` })
    },
    updateCollegeCostRelatedHtmls() {
      DCObject.$universitySpan.html(DCObject.resultOptions.collegeName)
      DCObject.$collegeStartYearSpan.html(DCObject.resultOptions.collegeStartYear)


      if (DCObject.collegeTotalCostWithoutExpenses !== 0 && DCObject.collegeTotalCost !== 0) {
        //DCObject.$totalCollegeCostSpan.html(parseInt(DCObject.collegeTotalCostWithoutExpenses).formatMoney(0))
        DCObject.$totalCollegeTuitionCostSpan.html(parseInt(DCObject.collegeTotalCostWithoutExpenses).formatMoney(0))
        DCObject.$additionalCostSpan.html(parseInt(DCObject.collegeTotalCost - DCObject.collegeTotalCostWithoutExpenses).formatMoney(0))
      }

    },
    infoHtmlUpdates() {
      let contributionDiffer = DCObject.initialMonthlyContribution - DCObject.monthlyContributionAmount,
        percentDiffer = 100 - DCObject.totalSavingsPercent

      
      if (contributionDiffer <= 0) {
        DCObject.$monthlySaveSpan.html(`$0/month`)
        DCObject.$monthlyContributionMessageSpan.html("The current monthly contribution will cover your funding goal!")
      } else {
        DCObject.$monthlySaveSpan.html(`$ ${contributionDiffer}/month`)
        DCObject.$monthlyContributionMessageSpan.html(`You'll need to increase your monthly contribution to <span class="bold">$${DCObject.initialMonthlyContribution}</span>` +
          ` in order to make your college savings goal.`)

        //of <span class="bold">${DCObject.idealSavings.formatMoney(0)}</span>
      }
    },
    topBoxInfoHtmlUpdates() {
      let collegeCat = DCObject.collegeCategory === "state-public" ? 'in state' : 'out of state',
        collegeCost = DCObject.additionalExpense === "yes" ? Math.ceil(DCObject.collegeTotalCost) : DCObject.collegeTotalCostWithoutExpenses,
        partialPercent = DCObject.investment === "partially" ? DCObject.savingsPartialPercentage * 100 : '100',
        childAge = DCObject.resultOptions.age > 1 ? DCObject.resultOptions.age + " years" : DCObject.resultOptions.age + " year",
        deficit = DCObject.totalDeficit,
        surplusOrGap = "",
        semesters = 0,
        semestersText = ""

        semesters = DCObject.calcSemester(collegeCost, DCObject.totalSavings, parseInt(DCObject.$collegeDurationOption.val()))

        if(semesters){
          //DCObject.$detailedCalculator.find('.total-savings-title .info-wrapper').show()
          switch (semesters){
            case 0: semestersText = "That's zero semester!"
            break;
            case 1: semestersText = "That's one full semester!"
            break;
            case 2: semestersText = "That's two full semesters!"
            break;
            case 3: semestersText = "That's three full semesters!"
            break;
            case 4: semestersText = "That's four full semesters!"
            break;
            case 5: semestersText = "That's five full semesters!"
            break;
            case 6: semestersText = "That's six full semesters!"
            break;
            case 7: semestersText = "That's seven full semesters!"
            break;
            case 8: semestersText = "That's eight full semesters!"
            break;
            default: semestersText = ""
            break;
          }
        } else {
          semestersText = "That's zero semester!"
          //DCObject.$detailedCalculator.find('.total-savings-title .info-wrapper').hide()
        }


        DCObject.$detailedCalculator.find('#semester-info').html(semestersText)

      deficit = deficit <= 0 ? deficit * -1 : deficit
      surplusOrGap = DCObject.totalDeficit <= 0 ? "Surplus" : "Gap"

      if (DCObject.resultOptions.collegeName) {
        DCObject.$infoYourGoal.find('.info').html(`Your child is <span class="bold">${childAge}</span>` +
          ` old and you selected <br><span class="bold text-rasberry">${DCObject.resultOptions.collegeName}</span>`)
        DCObject.$infoYourGoal.find('.info-bottom').html(`Years until college:&nbsp;&nbsp;<span class="bold">${18 - DCObject.resultOptions.age}</span><br/>` +
          `Total ${collegeCat} cost:&nbsp;&nbsp;<span class="bold">${parseInt(collegeCost).formatMoney(0)}</span>`)
        DCObject.$totalCollegeCostSpan.html(collegeCost.formatMoney(0))
      }

      if (DCObject.showYourNumbersSummary) {
        DCObject.$infoYourNumber.find('.info').html(`You are funding <span class="bold">${partialPercent}%</span>` +
          ` (${DCObject.idealSavings.formatMoney(0)})`)
        DCObject.$infoYourNumber.find('.info-bottom').html(`One-time investment:&nbsp;&nbsp;<span class="bold">${parseInt(DCObject.resultOptions.initialInvestment).formatMoney(0)}</span><br/>` +
          `Suggested monthly contribution:&nbsp;&nbsp;<span class="bold">${parseInt(DCObject.initialMonthlyContribution).formatMoney(0)}</span>`)
        DCObject.$detailedCalculator.find('.total-fund-percent').html(`${partialPercent}%`)
        DCObject.$detailedCalculator.find('.total-savings-percent').html(`${DCObject.totalSavingsPercent}%`)
      }

      if (DCObject.showReviewSummary) {
        DCObject.$infoYourSummary.find('.info').html(`Your funding goal&nbsp;&nbsp;<span class="bold">${DCObject.idealSavings.formatMoney(0)}</span>`)
        DCObject.$infoYourSummary.find('.info-bottom').html(`You will save:&nbsp;&nbsp;<span class="bold">${DCObject.totalSavings.formatMoney(0)}</span><br/>` +
          `${surplusOrGap}:&nbsp;&nbsp;<span class="bold">${deficit.formatMoney(0)}</span>`)
      }
    },
    _circleProgressInit() {
      let progressHolder = this.$circleProgressHolder,
        progressOverlay = progressHolder.find('.progress-circular__overlay')

      TweenLite.set(progressOverlay, { drawSVG: "0% 0%", rotation: -90, transformOrigin: "50% 50%" })
    },
    //Handler
    genderHandler() {
      DCObject.gender = this.value
    },
    collegeCategoryHandler() {
      DCObject.collegeCategory = this.value
      if (DCObject.additionalExpense === 'yes') {
        if (DCObject.collegeCategory === "state-public") {
          DCObject.resultOptions.currentAnnualCost = DCObject.collegeInStateFees
        } else if (DCObject.collegeCategory === "outofstate-public") {
          DCObject.resultOptions.currentAnnualCost = DCObject.collegeOutStateFees
        }
      } else {
        if (DCObject.collegeCategory === "state-public") {
          DCObject.resultOptions.currentAnnualCost = DCObject.collegeInStateFeesWithoutCost
        } else if (DCObject.collegeCategory === "outofstate-public") {
          DCObject.resultOptions.currentAnnualCost = DCObject.collegeOutStateFeesWithoutCost
        }
      }

      DCObject.callQuickResults(function(data) {
        DCObject.updateMonthlyContribution(data)
      })
    },

    additionalExpenseHandler() {
      DCObject.additionalExpense = this.value


      if (DCObject.additionalExpense === 'yes') {
        if (DCObject.collegeCategory === "state-public") {
          DCObject.resultOptions.currentAnnualCost = DCObject.collegeInStateFees
        } else if (DCObject.collegeCategory === "outofstate-public") {
          DCObject.resultOptions.currentAnnualCost = DCObject.collegeOutStateFees
        }
      } else {
        if (DCObject.collegeCategory === "state-public") {
          DCObject.resultOptions.currentAnnualCost = DCObject.collegeInStateFeesWithoutCost
        } else if (DCObject.collegeCategory === "outofstate-public") {
          DCObject.resultOptions.currentAnnualCost = DCObject.collegeOutStateFeesWithoutCost
        }
      }

      if (DCObject.resultOptions.collegeName !== "") {
        DCObject.callQuickResults(function(data) {
          DCObject.updateMonthlyContribution(data)
        })
      }
    },

    ageHandler() {
      DCObject.resultOptions.age = this.value
      DCObject.resultOptions.collegeStartYear = new Date().getFullYear() + 18 - parseInt(DCObject.resultOptions.age)
      DCObject.resultOptions.contributionAmount = 0
      if (DCObject.resultOptions.collegeName !== "") {
        DCObject.callQuickResults()
      }
    },
    savingsPercentageHandler() {
      DCObject.savingsPartialPercentage = this.value
      DCObject.resultOptions.percentToCover = DCObject.savingsPartialPercentage
      DCObject.callQuickResults(function(data) {
        DCObject.updateMonthlyContribution(data)
      })
    },

    houseHoldInputHandler() {
      DCObject._calculateMonthlySave()
      DCObject.callQuickResults()

    },

    inflationChangeHandler() {
      DCObject.resultOptions.annualInflation = this.value
      DCObject.callQuickResults(function(data) {
        DCObject.updateMonthlyContribution(data)
      })
    },

    annualGrowthChangeHandler() {
      DCObject.resultOptions.annualGrowthRate = this.value
      DCObject.callQuickResults()
    },

    collegeDurationHandler() {
      DCObject.resultOptions.collegeDuration = this.value
      DCObject.callQuickResults(function(data) {
        DCObject.updateMonthlyContribution(data)
      })
    },

    monthlyExpenseHandler() {
      DCObject._calculateMonthlySave()
      DCObject.callQuickResults()
    },
    investPlanHandler() {
      DCObject.$investChangerButton.removeClass('active')
      $(this).addClass('active')
      if ($(this).data('invest-format') === "partially") {
        DCObject.investment = "partially"
        DCObject.resultOptions.contributionAmount = 0
        DCObject.resultOptions.percentToCover = DCObject.savingsPartialPercentage
        DCObject.$percentageFullSpan.hide()
        DCObject.$percentageToggler.show()

      } else {
        DCObject.resultOptions.percentToCover = 1
        DCObject.resultOptions.contributionAmount = 0
        DCObject.investment = "fully"
        DCObject.$percentageToggler.hide()
        DCObject.$percentageFullSpan.show()
      }

      DCObject.callQuickResults(function(data) {
        DCObject.updateMonthlyContribution(data)
      })
    },

    updateMonthlyContribution(data) {
      DCObject.monthlyContributionAmount = Math.ceil(data.chartData.RequiredContribution)
      DCObject.$monthlyContributionInput.val(DCObject.monthlyContributionAmount)
      DCObject.initialMonthlyContribution = Math.ceil(data.chartData.RequiredContribution)


    },

    monthlyContributionHandler() {
      clearTimeout(DCObject.delayedApiCall)
      if (isNaN(this.value)) {
        return
      }

      let input = this


      DCObject.delayedApiCall = setTimeout(function() {

        DCObject.monthlyContributionAmount = input.value

        DCObject.resultOptions.contributionAmount = DCObject.monthlyContributionAmount
        DCObject.callQuickResults()
      }, 800)

    },
    oneTimeInvestmentHandler() {
      clearTimeout(DCObject.delayedApiCall)
      let input = this


      DCObject.delayedApiCall = setTimeout(function() {
        DCObject.resultOptions.initialInvestment = input.value
        if(parseInt(input.value)){
          //DCObject.resultOptions.contributionAmount = 0
        } else {
          //console.log(DCObject.initialMonthlyContribution)
        }
        DCObject.callQuickResults(function(data) {
          //DCObject.updateMonthlyContribution(data)
          //DCObject.$monthlyContributionInput.trigger('change')
        })
      }, 800)
    },

    userEditButtonHandler() {
      DCObject._calculateMonthlySave()
      DCObject.showYourNumbersSummary = true
      DCObject.callQuickResults()
    },

    reviewSummaryHandler() {
      let resultOptionPrevState = $.extend({}, DCObject.resultOptions)
      DCObject.showReviewSummary = true
      if (DCObject.additionalExpense === 'no') {

        if (DCObject.collegeCategory === "state-public") {
          DCObject.resultOptions.currentAnnualCost = DCObject.collegeInStateFees
        } else if (DCObject.collegeCategory === "outofstate-public") {
          DCObject.resultOptions.currentAnnualCost = DCObject.collegeOutStateFees
        }
        DCObject.callQuickResults((data) => {
          DCObject.collegeTotalCost = data.chartData.TotalCost
          DCObject.resultOptions = resultOptionPrevState
        }, true)

      } else {
        if (DCObject.collegeCategory === "state-public") {
          DCObject.resultOptions.currentAnnualCost = DCObject.collegeInStateFeesWithoutCost
        } else if (DCObject.collegeCategory === "outofstate-public") {
          DCObject.resultOptions.currentAnnualCost = DCObject.collegeOutStateFeesWithoutCost
        }
        DCObject.callQuickResults((data) => {
          DCObject.collegeTotalCostWithoutExpenses = data.chartData.TotalCost
          
          DCObject.resultOptions = resultOptionPrevState
        }, true)
      }

    },

    tabLinksHandler() {

      let target = this.href.split('#')[1]
      DCObject._animateBannerText(target)
      if ($(this).hasClass('active') || target === "savings-summary") return
      // if(target === 'your-numbers' || target === 'your-goal')
      // {
      //  DCObject.resultOptions.contributionAmount = 0 
      // }

      DCObject.resultOptions.contributionAmount = 0
      if (target === 'your-plan') {
        DCObject.userEditButtonHandler()
      }
      DCObject.callQuickResults()
    },

    // Tab travel to first step
    resetToFirst() {
      DCObject.$detailedCalculator.find('.tab-contents>.step').removeClass('active')
      DCObject.$detailedCalculator.find('.progressbar > li').removeClass('active completed')

      DCObject.$detailedCalculator.find('.tab-contents>.step:nth-child(1)').addClass('active')
      DCObject.$detailedCalculator.find('.progressbar > li:nth-child(1)').addClass('active')
      DCObject.$detailedCalculator.find('.info-box .info, .info-box .info-bottom').html('')
      DCObject.$detailedCalculator.find('.progressbar > li:nth-child(1) .info-box .info').html('Please select your funding goals')

    },

    // go to first step
    gotToFirstStep() {
      DCObject.$detailedCalculator.find('.tab-contents>.step').removeClass('active')
      DCObject.$detailedCalculator.find('.progressbar > li').removeClass('active completed')

      DCObject.$detailedCalculator.find('.tab-contents>.step:nth-child(1)').addClass('active')
      DCObject.$detailedCalculator.find('.progressbar > li:nth-child(1)').addClass('active')
    },

    // Reset action
    resetFunction(e) {
      e.preventDefault()
      $('html, body').animate({ scrollTop: DCObject.$detailedCalculator.offset().top - 100 })

      DCObject.$annualInflationOption.val(0.04).trigger('change')
      DCObject.$annualGrowthOption.val(0.08).trigger('change')
      DCObject.$ageOption.val(0).trigger('change')
      DCObject.$detailedCalculator.find('#instate-radio').attr('checked', true).trigger('click')
      DCObject.$detailedCalculator.find('#additional-expense-yes-radio').attr('checked', true).trigger('click')
      DCObject.$savingsPercentageOption.val(0.5).trigger('change')
      DCObject.$monthlyContributionInput.val(0).trigger('change')
      DCObject.$detailedCalculator.find('.invest-changer[data-invest-format="fully"]').trigger('click')
      DCObject.$collegeOption.val('').trigger('change')
      DCObject.$collegeDurationOption.val(4).trigger('change')

      DCObject.resultOptions = {
        age: 0,
        annualGrowthRate: DCObject.$annualGrowthOption.val(),
        annualInflation: DCObject.$annualInflationOption.val(),
        collegeDuration: 4,
        collegeStartAge: 18,
        collegeStartYear: new Date().getFullYear() + 18,
        currentAnnualCost: 0,
        collegeName: "",
        contributionType: "Monthly",
        contributionAmount: 0,
        initialInvestment: DCObject.$oneTimeInvestmentInput.val(),
        institutionID: null,
        percentToCover: 1,
        includeContributionIncrease: false,
        stepAmount: 0,
        stepStartDate: "2018.1",
        imageWidth: 306
      }
      DCObject.savingsPartialPercentage = DCObject.$savingsPercentageOption.val()
      DCObject.formError = false
      DCObject.collegeInStateFees = 0
      DCObject.collegeInStateFeesWithoutCost = 0
      DCObject.collegeOutStateFees = 0
      DCObject.collegeOutStateFeesWithoutCost = 0
      DCObject.collegeCategory = DCObject.$collegeCategoryChangeButton.val()
      DCObject.additionalExpense = DCObject.$additionalExpenseChooser.val()
      //this.monthlySave = 0,
      //this.userMonthlySave = 0,
      DCObject.monthlyContributionAmount = DCObject.$monthlyContributionInput.val()
      DCObject.initialMonthlyContribution = 0
      DCObject.monthlyContributionTotal = 0
      DCObject.idealSavings = 0
      //this.savingsMonthlyValue = 0
      DCObject.partialSavings = 0
      DCObject.investment = "fully"
      DCObject.totalSavings = 0
      DCObject.totalDeficit = 0
      DCObject.totalSavingsPercent = 0
      DCObject.collegeTotalCost = 0
      DCObject.collegeTotalCostWithoutExpenses = 0
      DCObject.delayedApiCall = null

      DCObject.showYourNumbersSummary = false
      DCObject.showReviewSummary = false




      DCObject.$additionalControlSpan.addClass('disabled')
      DCObject.$bottomActions.hide()
      DCObject.resetToFirst()

    },
    // Navigation handlers
    //next
    stepNext(e) {
      e.preventDefault()
      $('html, body').animate({ scrollTop: DCObject.$detailedCalculator.offset().top - 100 })
      DCObject.formError = false
      if (!DCObject.validate()) {
        DCObject.formError = true
        return
      }
      DCObject.current_fs = $(this).closest('.step');

      DCObject.next_fs = $(this).closest('.step').next();
      DCObject.previous_fs = $(this).closest('.step').prev();

      //activate next step on progressbar using the index of next_fs
      DCObject.$progressBarLi.eq($(".step").index(DCObject.next_fs)).addClass("active");
      DCObject.$progressBarLi.eq($(".step").index(DCObject.current_fs)).removeClass("active");
      DCObject.$progressBarLi.eq($(".step").index(DCObject.current_fs)).addClass("completed");

      //show the next fieldset
      DCObject.next_fs.addClass('active');
      DCObject.current_fs.removeClass('active');



      //DCObject._animateBannerText(DCObject.next_fs.attr('id'))

      if ($(this).data('calculate') === false) {

        return
      }

      if (!$(this).hasClass('user-edit-trigger')) {
        DCObject.resultOptions.contributionAmount = 0
        DCObject.resultOptions.initialInvestment = 0
        DCObject.$oneTimeInvestmentInput.val(0)
        DCObject.callQuickResults()
      }

      $('html, body').animate({ scrollTop: DCObject.$detailedCalculator.offset().top - 100 })
    },
    //prev
    stepPrev(e) {
      e.preventDefault()
      $('html, body').animate({ scrollTop: DCObject.$detailedCalculator.offset().top - 100 })
      DCObject.current_fs = $(this).closest('.step');
      DCObject.previous_fs = $(this).closest('.step').prev();

      //de-activate current step on progressbar
      $(".progressbar li").eq($(".step").index(DCObject.current_fs)).removeClass("active");
      $(".progressbar li").eq($(".step").index(DCObject.current_fs)).removeClass("completed");
      $(".progressbar li").eq($(".step").index(DCObject.previous_fs)).addClass("active");

      //show the previous fieldset
      DCObject.current_fs.removeClass('active');
      DCObject.previous_fs.addClass('active');

      //DCObject._animateBannerText(DCObject.previous_fs.attr('id'))
      if ($(this).data('calculate') === false) {
        return
      }
      DCObject.resultOptions.contributionAmount = 0
      DCObject.resultOptions.initialInvestment = 0
      DCObject.$oneTimeInvestmentInput.val(0)
      DCObject.callQuickResults()


    },
    //inner next
    stepNextInner() {
      DCObject.current_fs = $(this).closest('.inner-step');
      DCObject.next_fs = $(this).closest('.inner-step').next();

      //show the next fieldset
      DCObject.next_fs.addClass('active');
      DCObject.current_fs.removeClass('active');
    },
    //inner prev
    stepPrevInner() {
      DCObject.current_fs = $(this).closest('.inner-step');
      DCObject.previous_fs = $(this).closest('.inner-step').prev();

      //show the previous fieldset
      DCObject.current_fs.removeClass('active');
      DCObject.previous_fs.addClass('active');
    },

    // binding events
    _eventListeners() {
      // Next Button
      this.$nextBtn.click(this.stepNext)
      // Prev Button
      this.$prevBtn.click(this.stepPrev)
      // Inner next
      this.$nextBtnInner.click(this.stepNextInner)
      // Inner prev
      this.$prevBtnInner.click(this.stepPrevInner)
      //gender
      this.$genderOption.on('change', this.genderHandler)
      // CollegeCategory
      //this.$collegeCategoryOption.on('change', this.collegeCategoryHandler)
      this.$collegeCategoryChangeButton.on('change', this.collegeCategoryHandler)
      // Additional expense change
      this.$additionalExpenseChooser.on('change', this.additionalExpenseHandler)
      // student age
      this.$ageOption.on('change', this.ageHandler)
      //Savings percentage
      this.$savingsPercentageOption.on('change', this.savingsPercentageHandler)
      //House hold incom input
      this.$houseHoldInput.on('change', this.houseHoldInputHandler)
      //Monthly expense savings input
      this.$monthlyExpenseInput.on('change', this.monthlyExpenseHandler)
      // Inflation change
      this.$annualInflationOption.on('change', this.inflationChangeHandler)
      // Annual Growth change
      this.$annualGrowthOption.on('change', this.annualGrowthChangeHandler)
      // Monthly contriution
      this.$monthlyContributionInput.on('keydown change', this.monthlyContributionHandler)
      // only number vcalidator
      this.$houseHoldInput.on('keypress', this.onlyNumber)
      this.$monthlyExpenseInput.on('keypress', this.onlyNumber)
      // Invest changer tab
      this.$investChangerButton.on('click', this.investPlanHandler)
      // useredit
      this.$userEditTrigger.on('click', this.userEditButtonHandler)
      // Review plan btn
      this.$reviewPlanBtn.on('click', this.reviewSummaryHandler)
      // Select duration
      this.$collegeDurationOption.on('change', this.collegeDurationHandler)

      // One time investment input
      this.$oneTimeInvestmentInput.on('keydown', this.oneTimeInvestmentHandler)

      // Reset handler
      this.$resetButton.on('click', this.resetFunction)

      // Tab event listener
      this.$tabLinks.on('click', this.tabLinksHandler)
    }
  }

  new DetailedCalculator() // Calling new instance

})(window)
