//var current_fs, next_fs, previous_fs; //fieldsets
//var left, opacity, scale; //fieldset properties which we will animate
//var animating; //flag to prevent quick multi-click glitches

//Next step button implementation
// $(".next").click(function () {
//   // $('.right-slider')
//   current_fs = $(this).closest('.step');

//   next_fs = $(this).closest('.step').next();
//   previous_fs = $(this).closest('.step').prev();

//   //activate next step on progressbar using the index of next_fs
//   $(".progressbar li").eq($(".step").index(next_fs)).addClass("active");
//   $(".progressbar li").eq($(".step").index(current_fs)).removeClass("active");
//   $(".progressbar li").eq($(".step").index(current_fs)).addClass("completed");

//   //show the next fieldset
//   next_fs.addClass('active');
//   current_fs.removeClass('active');
// });

// Previous step button implementation
// $(".previous").click(function () {
//   current_fs = $(this).closest('.step');
//   previous_fs = $(this).closest('.step').prev();

//   //de-activate current step on progressbar
//   $(".progressbar li").eq($(".step").index(current_fs)).removeClass("active");
//   $(".progressbar li").eq($(".step").index(previous_fs)).addClass("active");

//   //show the previous fieldset
//   current_fs.removeClass('active');
//   previous_fs.addClass('active');
// });


// $(".inner-next").click(function () {
//   current_fs = $(this).closest('.inner-step');
//   next_fs = $(this).closest('.inner-step').next();

//   //show the next fieldset
//   next_fs.addClass('active');
//   current_fs.removeClass('active');
// });

// $(".inner-previous").click(function () {
//   current_fs = $(this).closest('.inner-step');
//   previous_fs = $(this).closest('.inner-step').prev();

//   //show the previous fieldset
//   current_fs.removeClass('active');
//   previous_fs.addClass('active');
// });

