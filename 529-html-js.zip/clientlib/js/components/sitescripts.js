// import ScrollMagic from 'ScrollMagic'
// import $ from 'jquery'
$('.carousel-slides').slick({
  slidesToShow: 2
})

import { bannerSlider } from "./planselectionscript"

var s, NF = {
  init: function() {
    s = this.settings
    this.select()
    this.selectAll()
    this.scrollDierectionChecker()
    this.detectAnimation()
    this.smoothScrolling()
    this.resizeListner()
    this.scrollBarWidth()
    this.removeMethod()
    this.tabs()
    this.forAnalytics()
    //this.navigationSlider();
    this.tabAnchors()
    this.accordian()
    this.tableAccoridan()
    this.hamburger()
    this.parallaxBg()
    
    this.moneyFormat()
    this.hoversAnimation()
    this.sideNavigationDropDown()
    this.lazyload()
    this.articleSlider()
    this.infoSlider()
    this.tabLinkSlider()
    this.smoothScrolls()
    this.compareTable()
    this.affix()
    this.infoOVers()
    this.scrollSpy()
    this.dateToday()
    if($('.plan-selection-area').length){
      new bannerSlider()
    }
    
    //this.headerScrollOut()
    //this.contentSlider();
  },
  loaded: false,
  // Settings
  settings: {

    desktop: 1200,
    tab: 1024,
    mobile: 768,
    scrollClassTrigger: 100,
    windowWidth: window.innerWidth,
    windowheight: window.innerHeight,
    scrollBarWidth: 0,
    stageBoxEntered: false
  },

  select() {
    return window.select = (s, e) => {
      if (e) {
        return e.querySelector(s)
      }
      return document.querySelector(s)
    }
  },
  selectAll() {
    return window.selectAll = (s, e) => {
      if (e) {
        return e.querySelectorAll(s)
      }
      return document.querySelectorAll(s)
    }
  },
  detectIe: function() {

    var ua = window.navigator.userAgent;

    var msie = ua.indexOf('MSIE ');
    if (msie > 0) {
      // IE 10 or older => return version number
      return parseInt(ua.substring(msie + 5, ua.indexOf('.', msie)), 10);
    }

    var trident = ua.indexOf('Trident/');
    if (trident > 0) {
      // IE 11 => return version number
      var rv = ua.indexOf('rv:');
      return parseInt(ua.substring(rv + 3, ua.indexOf('.', rv)), 10);
    }

    var edge = ua.indexOf('Edge/');
    if (edge > 0) {
      // Edge (IE 12+) => return version number
      return parseInt(ua.substring(edge + 5, ua.indexOf('.', edge)), 10);
    }

    // other browser
    return false;

  },

  moneyFormat() {
    Number.prototype.formatMoney = function(c, d, t) {
      var n = this,
        c = isNaN(c = Math.abs(c)) ? 2 : c,
        d = d == undefined ? "." : d,
        t = t == undefined ? "," : t,
        s = n < 0 ? "-" : "",
        i = String(parseInt(n = Math.abs(Number(n) || 0).toFixed(c))),
        j = (j = i.length) > 3 ? j % 3 : 0;
      return s + '$' + (j ? i.substr(0, j) + t : "") + i.substr(j).replace(/(\d{3})(?=\d)/g, "$1" + t) + (c ? d + Math.abs(n - i).toFixed(c).slice(2) : "");
    }
  },

  // ResizeListner
  resizeListner: function() {
    window.addEventListener("resize", function() {
      s.windowheight = window.innerHeight;
      s.windowWidth = window.innerWidth;

      //NF.windowheight();
    });

  },

  //scroll listener
  scrollListener() {

    const scrollFunction = () => {

    }

    window.onscroll = scrollFunction
  },

  //forAnalytics
  forAnalytics() {
    let calcDivs = $('#howtostart-graph,#howtostart-graph-b');

    $('body').on('click', function(e){
      NF.removeDatasRelated(e);
    })
  },

  removeDatasRelated(e) {
    // var data = $(elem).data();
    // var keys = $.map(data, function (value, key) {

    //     return key;
    // });

    // for (let i = 0; i < keys.length; i++) {
    //     $(elem).removeAttr("data-" + keys[i]);

    // }
    let elem;
    if($(e.target).parents('#howtostart-graph').length) {
      elem = $(e.target).parents('#howtostart-graph')
    } else if($(e.target).parents('#howtostart-graph-b').length){
      elem = $(e.target).parents('#howtostart-graph-b')
    } else {
      elem = $(e.target)
    }
    
    if(elem.data("analytics-label")){
      elem.removeAttr("data-analytics-label");
    }
    if(elem.data("analytics-id")){
      elem.removeAttr("data-analytics-id");
    }
    if(elem.data("analytics-placement")){
      elem.removeAttr("data-analytics-placement");
    }
    
  },

  headerScrollOut() {
    let scrollController = new ScrollMagic.Controller(),
      mainWrapper = select('#main-wrapper'),
      mainHeader = select('#main-header'),
      tween = TweenLite.to(mainHeader, 0.5, { y: "-100%" })

    new ScrollMagic.Scene({
        triggerHook: 'onLeave',
        offset: -0,
        reverse: true,
        duration: 150
      })
      .setTween(tween)
      .addTo(scrollController)
  },

  // Window height calculator
  windowheight: function() {
    var body = document.querySelector('.window_height');
    body.style.height = s.windowheight + 'px';
  },

  hamburger: function() {
    let menus = selectAll('.hamburger-menu')
    menus.forEach(menu => {
      menu.addEventListener("click", () => {
        let target = menu.dataset.target
        select('#' + target).classList.toggle('active')
      })
    })

  },

  // Adding scroll class
  scrollDierectionChecker: function() {

    function scrollCheck() {
      if (window.scrollY > s.scrollClassTrigger) {
        document.querySelector('body').classList.add('scrolled');
      } else {
        document.querySelector('body').classList.remove('scrolled');
      }
    }

    function scrollDirCheck(e) {
      var delta = ((e.deltaY || -e.wheelDelta || e.detail) >> 10) || 1;;
      if (delta > 0) {

        document.querySelector('body').classList.remove('scrolling-up');
        document.querySelector('body').classList.add('scrolling-down');
      } else {
        document.querySelector('body').classList.remove('scrolling-down');
        document.querySelector('body').classList.add('scrolling-up');
      }
    }

    window.onscroll = function() { scrollCheck() };
    window.addEventListener('mousewheel', scrollDirCheck);
    window.addEventListener('DOMMouseScroll', scrollDirCheck);

  },



  //Update scroll bar width
  scrollBarWidth: function() {
    var outer = document.createElement("div");
    outer.style.visibility = "hidden";
    outer.style.width = "100px";
    outer.style.msOverflowStyle = "scrollbar"; // needed for WinJS apps

    document.body.appendChild(outer);

    var widthNoScroll = outer.offsetWidth;
    // force scrollbars
    outer.style.overflow = "scroll";

    // add innerdiv
    var inner = document.createElement("div");
    inner.style.width = "100%";
    outer.appendChild(inner);

    var widthWithScroll = inner.offsetWidth;

    // remove divs
    outer.parentNode.removeChild(outer);

    s.scrollBarWidth = widthNoScroll - widthWithScroll;


  },


  smoothScrolling: function() {
    // Smooth scrolling using jQuery easing
    $('a.scroll-trigger[href*="#"]:not([href="#"])').click(function() {
      if (location.pathname.replace(/^\//, '') == this.pathname.replace(/^\//, '') && location.hostname == this.hostname) {
        var target = $(this.hash);
        target = target.length ? target : $('[name=' + this.hash.slice(1) + ']');
        if (target.length) {
          $('html, body').animate({
            scrollTop: (target.offset().top - 56)
          }, 800);
          return false;
        }
      }
    });

  },



  removeMethod: function() {
    if (!('remove' in Element.prototype)) {
      Element.prototype.remove = function() {
        if (this.parentNode) {
          this.parentNode.removeChild(this);
        }
      };
    }
  },

  tabAnchors() {
    let tabAnchors = selectAll('.tab-anchor'),
      tabLinks = selectAll('.tab-link>a')
    tabAnchors.forEach(link => {
      link.addEventListener('click', function(e) {
        e.preventDefault()
        let target = $(this).data('relate')
        tabLinks.forEach(link => {
          if (link.href.split('#')[1] === target) {
            link.click()
          }
        })

      })

    })
  },
  tabLinkSlider() {
    let elem = $('.tab-links-slider'),
    toShow = elem.data('items') ? elem.data('items') : 3
    
    elem.slick({
      arrows: true,
      infinite: false,
      //initialSlide: 1,
      //centerMode: true,
      //centerPadding: '12%',
      dots: false,
      slidesToShow: toShow,
      speed: 500,
      responsive: [{
        breakpoint: 769,
        settings: {

          //centerMode: true,
          //centerPadding: '10%',
          slidesToShow: 3
        }
      },{
        breakpoint: 742,
        settings: {

          //centerMode: true,
          //centerPadding: '10%',
          slidesToShow: 2
        }
      }, {
        breakpoint: 567,
        settings: {
          centerMode: true,
          centerPadding: '10%',
          slidesToShow: 1
        }
      }]
    });
  },
  hashing(id){
    var url = window.location.href.split('#')[0],
    scrollTop = window.scrollY
    url += '#' + id

    //parent.location.hash = id;
    //window.location.href = url
    //window.scrollTo(0,scrollTop);

    window.history.replaceState('', '',url);


  },
  tabs() {
    let tabLinks = selectAll('.tab-link>a'),
      tabContents = selectAll('.tab-contents>div'),
      removeInitial = function(parent) {
        
        let tabLinks = $(parent).find('.tab-link').removeClass('active')
        tabContents = $(parent).find('.tab-contents>div').removeClass('active')

        // tabLinks.forEach(link => {
        //   link.parentNode.classList.remove('active')
        // })
        // tabContents.forEach(content => {
        //   content.classList.remove('active')
        // })
      }



    function checkingHash() {
      let hashTargetId = window.location.href.split('#')[1],
          tabContent = document.getElementById(hashTargetId)
      
      if(tabContent){
        removeInitial('.tab-wrapper')
        tabLinks.forEach(link => {
          let linkTarget = link.href.split('#')[1]
          if(linkTarget === hashTargetId){
            tabContent.classList.add('active')
            link.parentNode.classList.add('active')
            let tabWrapper = $(link).closest('.tab-wrapper')
            window.scrollTo(0,0);
            $('html,body').animate({scrollTop: tabWrapper.offset().top - 200})
            
          }
        })
      }
    }
    checkingHash()
    //window.onhashchange = checkingHash;
    tabLinks.forEach(link => {
      link.addEventListener('click', (e) => {
        if ($(link).data('external')) {
          return
        }
        e.preventDefault()
        removeInitial($(link).parents('.tab-wrapper'))
        let target = link.href.split('#')[1]
        this.hashing(target)
        select('#' + target).classList.add('active')
        link.parentNode.classList.add('active')
        let tabWrapper = $(link).closest('.tab-wrapper')
        $('html,body').animate({scrollTop: tabWrapper.offset().top - 200})
      })
    })
  },

  // Parallax bg
  parallaxBg: function() {
    var slides = document.querySelectorAll(".parallax-element");
    var scrollController = new ScrollMagic.Controller();
    for (var i = 0; i < slides.length; i++) {
      var tween = TweenLite.fromTo(slides[i], 3, { y: '0%', rotation: '.01deg' }, { y: '80%', rotation: '.01deg', ease: Linear.easeNone });
      var scene = new ScrollMagic.Scene({ duration: 3000, triggerElement: slides[i], triggerHook: 'onEnter' })
        .setTween(tween)
        .addTo(scrollController);
    }

    $(window).on("resize load", function(e) {
      if ($(window).width() < 992) {
        scrollController.enabled(false);
        // console.log(scrollController);
      } else if (!scrollController.enabled()) {
        $(slides).addClass('no-parallax');
        scrollController.enabled(true);
      }
      scrollController.update(true);
    });
  },

  // Navigation Slider
  navigationSlider() {
    let elem = $('.navigation-tablinks-wrapper')
    elem.slick({
      arrows: false,
      infinite: false,
      //initialSlide: 1,
      //centerMode: true,
      //centerPadding: '12%',
      dots: false,
      slidesToShow: 5,
      speed: 500,
      responsive: [{
        breakpoint: 742,
        settings: {

          centerMode: true,
          centerPadding: '10%',
          slidesToShow: 3
        }
      }, {
        breakpoint: 567,
        settings: {

          centerMode: true,
          centerPadding: '10%',
          slidesToShow: 2
        }
      }, {
        breakpoint: 402,
        settings: {

          centerMode: true,
          centerPadding: '10%',
          slidesToShow: 1
        }
      }]
    });
  },
  //article slider
  articleSlider() {
    let elem = $('.article-slider-list')

    elem.slick({
      dots: true,
      infinite: true,
      arrows: false,
      speed: 500,
      fade: true,
      cssEase: 'linear',
      autoplay: true
    });
  },

  infoSlider() {
    let elem = $('.info-slider')

    elem.slick({
      dots: false,
      infinite: true,
      arrows: false,
      speed: 500,
      autoplaySpeed: 8000,
      draggable: false,
      //fade: true,
      cssEase: 'linear',
      pauseOnFocus: false,
      autoplay: true,
      adaptiveHeight: true
    })
  },

  smoothScrolls() {

    $('a.anchor-link[href*="#"]:not([href="#"])').click(function() {
      if (location.pathname.replace(/^\//, '') == this.pathname.replace(/^\//, '') && location.hostname == this.hostname) {
        var target = $(this.hash);
        target = target.length ? target : $('[name=' + this.hash.slice(1) + ']');

        var offset = 110
        if($(this).data('offset-more')){
          offset = 500
        }
        if (target.length) {
          $('html, body').animate({
            scrollTop: (target.offset().top - offset)
          }, 500);
          return false;
        }
      }
    });
  },

  fallingLeavesRepeatAnimation(leaves) {
    let tl = new TimelineMax()
        TweenLite.set(leaves, {autoAlpha: 0, x: -10})
        TweenLite.set([leaves[0],leaves[1],leaves[2],leaves[3],leaves[6]], {autoAlpha: 0, y: -700})
        TweenLite.set(leaves[4],{scale: 0.8, x: 0})
        leaves.each(function() {
           tl.to(this, 1, {autoAlpha: 1})
           .to(this, Math.random() * 10 + 5, {
              autoAlpha: 1,
              y: 600,
              x: -20,
              repeat: -1,
              transformOrigin: '50% 50%'
            }, 0)
           .to(this, Math.random() * 1 + 0.5, {
            x : 20,
            repeat: -1,
            yoyo: true,
            ease: Power1.easeInOut,
           }, 0)
           .to(this, 3,{
            rotation: 360,
            repeat: -1,
            ease: Linear.easeNone,
            transformOrigin: '50% 50%'
           },0)
        })

    return tl
  },
  // Detect animations
  detectAnimation: function() {
    var controller = new ScrollMagic.Controller();
    var elem = $('.detect-animate');

    elem.each(function() {
      var elem = this;
      var triggerElem = $(elem).data('top') ? $(elem).data('top') : elem;
      var elementAnimation = $(elem).data('animation');
      var delay = $(elem).data('delay') ? $(elem).data('delay') : 0;
      var speed = $(elem).data('speed') ? $(elem).data('speed') : 1;
      var hook = $(elem).data('hook') ? $(elem).data('hook') : 'onEnter';
      var tween = '';
      var duration = 0;
      var reverse = ($(elem).data('reverse') === false) ? false : true;
      var staggerOffset = 0.1;

      TweenLite.set(elem, { autoAlpha: 1 });

      switch (elementAnimation) {
        case "fade-in":
          tween = TweenMax.from(elem, speed, { autoAlpha: 0, ease: Ease.ease, delay: delay });
          break;
        case "from-top":
          tween = TweenMax.from(elem, speed, { y: '-100px', opacity: 0, ease: Ease.ease, delay: delay });
          break;
        case "from-top-jerk":
          tween = TweenMax.from(elem, speedspeed, { y: '-100px', opacity: 0, ease: Back.easeInOut, delay: delay });
          break;
        case "from-bottom":
          tween = TweenMax.from(elem, speed, { y: '100px', opacity: 0, ease: Ease.ease, delay: delay });
          break;
        case "from-bottom-jerk":
          tween = TweenMax.from(elem, speed, { y: '100px', opacity: 0, ease: Back.easeInOut, delay: delay });
          break;
        case "from-left":
          tween = TweenMax.from(elem, speed, { x: '-100px', opacity: 0, ease: Ease.ease, delay: delay });
          break;
        case "from-left-jerk":
          tween = TweenMax.from(elem, speed, { x: '-100px', opacity: 0, ease: Back.easeInOut, delay: delay });
          break;
        case "from-right":
          tween = TweenMax.from(elem, speed, { x: '100px', opacity: 0, ease: Ease.ease, delay: delay });
          break;
        case "from-right-jerk":
          tween = TweenMax.from(elem, speed, { x: '100px', opacity: 0, ease: Back.easeInOut, delay: delay });
          break;
        case "from-bottom-elements-lazy":
          tween = TweenMax.staggerFrom($(elem).find('>*'), speed, { y: '100px', opacity: 0, ease: Ease.ease, delay: delay }, staggerOffset);
          break;
        case "from-bottom-elements-lazy-jerk":
          tween = TweenMax.staggerFrom($(elem).find('>*'), speed, { y: '100px', opacity: 0, ease: Back.easeInOut, delay: delay }, staggerOffset);
          break;
        case "from-left-elements-lazy":
          tween = TweenMax.staggerFrom($(elem).find('>*'), speed, { x: '-100px', opacity: 0, ease: Ease.ease, delay: delay }, staggerOffset);
          break;
        case "from-left-elements-lazy-jerk":
          tween = TweenMax.staggerFrom($(elem).find('>*'), speed, { x: '-100px', opacity: 0, ease: Back.easeInOut, delay: delay }, staggerOffset);
          break;
        case "from-right-elements-lazy":
          tween = TweenMax.staggerFrom($(elem).find('>*'), speed, { x: '100px', opacity: 0, ease: Ease.ease, delay: delay }, staggerOffset);
          break;
        case "from-right-elements-lazy-jerk":
          tween = TweenMax.staggerFrom($(elem).find('>*'), speed, { x: '100px', opacity: 0, ease: Back.easeInOut, delay: delay }, staggerOffset);
          break;
        case "from-top-elements-lazy":
          tween = TweenMax.staggerFrom($(elem).find('>*'), speed, { y: '-100px', opacity: 0, ease: Ease.ease, delay: delay }, staggerOffset);
          break;
        case "from-bottom-items-lazy":
          tween = TweenMax.staggerFrom($(elem).find('.animate-item'), speed, { y: '100px', opacity: 0, ease: Ease.ease, delay: delay }, staggerOffset);
          break;
        case "from-bottom-items-lazy-jerk":
          tween = TweenMax.staggerFrom($(elem).find('.animate-item'), speed, { y: '100px', opacity: 0, ease: Back.easeInOut, delay: delay }, staggerOffset);
          break;
        case "from-left-items-lazy":
          tween = TweenMax.staggerFrom($(elem).find('.animate-item'), speed, { x: '-100px', opacity: 0, ease: Ease.ease, delay: delay }, staggerOffset);
          break;
        case "from-left-items-lazy-jerk":
          tween = TweenMax.staggerFrom($(elem).find('.animate-item'), speed, { x: '-100px', opacity: 0, ease: Back.easeInOut, delay: delay }, staggerOffset);
          break;
        case "life-stage-animation":
          let stageBoxes = $(elem).find('.life-stage-box')
          tween = new TimelineMax({
            onComplete: () => {
              s.stageBoxEntered = true
            }
          })
          tween.staggerFrom(stageBoxes, 0.8, { x: -100, autoAlpha: 0 }, 0.05)
            .add(() => {
              NF.lifeBoxActiveTransition($(elem).find('.life-stage-box.active'))
            }, 0)
          break;
        case "father-son":
          let fatherSon = $(elem).find('#father-son'),
            fatherSonLand = $(elem).find('#father-son-land'),
            lampPost = $(elem).find('#father-son-lamp-post'),
            lampShadow = $(elem).find('.lamp-shadow'),
            leaves = $(elem).find('#father-son-falling-leaves>path'),
            plant1 = $(elem).find('#father-son-plant-1'),
            plant2 = $(elem).find('#father-son-plant-2'),
            plant3 = $(elem).find('#father-son-plant-2'),
            tweenPlant1 = new TimelineMax(),
            tweenPlant2 = new TimelineMax(),
            tweenPlant3 = new TimelineMax()
          tween = new TimelineMax()
          tween.add(NF.fallingLeavesRepeatAnimation(leaves), 0.05)
            .from(fatherSon, 1, { autoAlpha: 0, scale: 1.1 }, 1)
            .from(fatherSonLand, 1, { autoAlpha: 0, scale: 1.1 }, 1.2)
            .from([lampPost, lampShadow], 1, { autoAlpha: 0, scale: 0.9, transformOrigin: "left bottom" }, 1.2)
          //.add(tweenPlant1)

          let timeOffset = 0.3;

          for (let i = 1; i <= 3; i++) {
            tween.add('plant' + i)
              .from($(elem).find('#father-son-plant-' + i + ' .plant-stem'), 1, {
                autoAlpha: 0,
                scaleX: 0.2,
                transformOrigin: '50% 100%'
              }, timeOffset)
              .staggerFrom($(elem).find('#father-son-plant-' + i + ' .plant-leaves>.right-leaves>path'), 2.5, {
                autoAlpha: 0,
                rotation: 45,
                ease: Elastic.easeOut.config(1, 0.3),
                transformOrigin: "left center"
              }, 0.05, timeOffset + 0.2)
              .staggerFrom($(elem).find('#father-son-plant-' + i + ' .plant-leaves>.left-leaves>path'), 2.5, {
                autoAlpha: 0,
                rotation: -80,
                ease: Elastic.easeOut.config(1, 0.3),
                transformOrigin: "right center"
              }, 0.05, timeOffset + 0.2)

            timeOffset += 0.3
          }
          //tweenPlant1

          //.staggerFrom(plant1.find('.plant-leaves>.left-leaves>path'),1,{autoAlpha: 0, rotation:-80, ease: Back.easeOut.config(2), transformOrigin:"right center"},0.05,0.2)
          break;
        case "leaves":
          var fallingLeaves = $(elem).find('.falling-leaves>path'),
            plant1 = $(elem).find('.plant-1'),
            plant2 = $(elem).find('.plant-2'),
            plant3 = $(elem).find('.plant-2')
          tween = new TimelineMax()
          tween.staggerFrom(fallingLeaves, 2, { autoAlpha: 0, y: -100, rotation: 180, transformOrigin: '50% 50%' }, 0.05)

          var timeOffset = 0.3;

          for (let i = 1; i <= 3; i++) {
            tween.add('plant' + i)
              .from($(elem).find('.plant-' + i + ' .plant-stem'), 1, {
                autoAlpha: 0,
                scaleX: 0.2,
                transformOrigin: '50% 100%'
              }, timeOffset)
              .staggerFrom($(elem).find('.plant-' + i + ' .plant-leaves>.right-leaves>path'), 2.5, {
                autoAlpha: 0,
                rotation: 45,
                ease: Elastic.easeOut.config(1, 0.3),
                transformOrigin: "left center"
              }, 0.05, timeOffset + 0.2)
              .staggerFrom($(elem).find('.plant-' + i + ' .plant-leaves>.left-leaves>path'), 2.5, {
                autoAlpha: 0,
                rotation: -80,
                ease: Elastic.easeOut.config(1, 0.3),
                transformOrigin: "right center"
              }, 0.05, timeOffset + 0.2)

            timeOffset += 0.3
          }
          break;
        case "advisors":
          tween = new TimelineMax()
          tween.staggerFrom($(elem).find('>.people-canvas>img:not(.fpo)'), 1, {
            z: -500,
            autoAlpha: 0,
            ease: Back.easeOut
          }, 0.08)
          break
        default:
          tween = '';
      };

      new ScrollMagic.Scene({ triggerElement: triggerElem, triggerHook: hook, duration: duration, reverse: false })
        .setTween(tween)
        .addTo(controller);


    });
  },

  lifeBoxActiveTransition(activeBox) {
    let tl = new TimelineMax(),
      hoverBg = $(activeBox).find('.hover-bg'),
      character = $(activeBox).find('.character-div'),
      article = $(activeBox).find('.article'),
      articleTitle = $(activeBox).find('.article>h2'),
      articlePara = $(activeBox).find('.article>.article-para'),
      bottomLink = $(activeBox).find('.bottom-link>strong'),
      bottomAction = $(activeBox).find('.bottom-action'),
      easing = Power1.easeOut

    tl.to(activeBox, 0.5, { width: '30%', height: 660 }, 0)
      .to(hoverBg, 0.5, { autoAlpha: 1 }, 0)
      .to(character, 0.5, { scale: 1, bottom: '45%' }, 0)
      .to(article, 0.5, { top: '68%' }, 0)
      .to(articleTitle, 0.5, { scale: 1.8, transformOrigin: '0% 100%' }, 0)
      .to(articlePara, 0.5, { autoAlpha: 1, y: 0 }, 0.2)
      .to(bottomLink, 0.8, { marginLeft: 0, ease: Back.easeInOut }, 0)
  },
  lifeBoxLeaveTransition(stageBox) {
    let tl = new TimelineMax(),
      hoverBg = $(stageBox).find('.hover-bg'),
      character = $(stageBox).find('.character-div'),
      article = $(stageBox).find('.article'),
      articleTitle = $(stageBox).find('.article>h2'),
      articlePara = $(stageBox).find('.article>.article-para'),
      bottomLink = $(stageBox).find('.bottom-link>strong'),
      bottomAction = $(stageBox).find('.bottom-action')

    tl.to(stageBox, 0.5, { width: '17.5%', height: 630, overwrite: 'all' }, 0)
      .to(hoverBg, 0.5, { autoAlpha: 0, overwrite: 'all' }, 0)
      .to(character, 0.5, { scale: 0.6, bottom: '35%', overwrite: 'all' }, 0)
      .to(article, 0.5, { top: '75%', overwrite: 'all' }, 0)
      .to(articleTitle, 0.5, { scale: 1, transformOrigin: '0% 100%', overwrite: 'all' }, 0)
      .to(articlePara, 0.5, { autoAlpha: 0, y: 50, overwrite: 'all' }, 0)
      .to(bottomLink, 0.8, { marginLeft: -150, ease: Back.easeIn, overwrite: 'all' }, 0)
  },

  lazyload: function() {
    var controller = new ScrollMagic.Controller(),
      mobBreak = 1025;

    var processFigure = function(figure) {

      var src = $(figure).data('src'),
        mobSrc = $(figure).data('mob-src'),
        loadingSrc = "";

      if (mobSrc) {
        if (s.windowWidth < mobBreak) {
          loadingSrc = mobSrc
        } else {
          loadingSrc = src
        }
      } else {
        loadingSrc = src
      }
      if (loadingSrc) {
        var img = $("<img />").attr('src', loadingSrc)
        if (img.complete) {
          giveImage(loadingSrc);
        } else {
          img.on('load', function() {
              giveImage(loadingSrc);
            })
            .on('error', function() {
              // giveImage('assets/images/no-preview-available.png');
            })
        }
      }



      function giveImage(src) {
        $(figure).css('background-image', 'url(' + src + ')');
        $(figure).removeClass('preload_background')
        $(figure).addClass('loaded');
        //$(figure).data('src', '');
      }
    }



    var $images = $('.lazyload-bg');

    for (var i = 0; i < $images.length; i++) {

      var scene = new ScrollMagic.Scene({ triggerElement: $images[i], triggerHook: 'onEnter' })
        .on('enter', function() {
          var triggerElem = this.triggerElement();
          console.log('entered');
          processFigure(triggerElem);
          window.addEventListener('resize', function() {
            processFigure(triggerElem)
          })
        })
        .addTo(controller);

    }
  },

  hoversAnimation() {
    let ctaBox = $('.cta-box')
    if (s.windowWidth > 960) {
      ctaBox.hover(mouseOn, mouseOut)
      TweenLite.set(ctaBox.find('.hover-content>article>*'), { y: 50, autoAlpha: 0 })
    }


    function mouseOn() {
      let animateElements = $(this).find('.hover-content>article>*'),
        hoverContent = $(this).find('.hover-content'),
        headerText = $(this).find('.title-box>*')

      let tl = new TimelineLite()
      tl.staggerTo(headerText, 0.3, { y: 50, autoAlpha: 0 }, -0.05)
        .to(hoverContent, 0.3, { autoAlpha: 1, height: '100%' }, 0.1)
        .staggerTo(animateElements, 0.3, {
          y: 0,
          autoAlpha: 1
        }, 0.1, 0.3)
    }

    function mouseOut() {
      let animateElements = $(this).find('.hover-content>article>*'),
        hoverContent = $(this).find('.hover-content'),
        headerText = $(this).find('.title-box>*')
      let tl = new TimelineLite()
      tl.staggerTo(headerText, 0.3, { y: 0, autoAlpha: 1 }, 0.05, 0.2)
        .to(hoverContent, 0.3, { autoAlpha: 0, height: '100%', overwrite: "all" }, 0.2)
        .staggerTo(animateElements, 0.3, {
          y: 50,
          autoAlpha: 0,
          overwrite: "all"
        }, -0.1, 0)
    }


    // Life stage box
    let lifeStageBox = $('.life-stage-box')


    lifeStageBox.hover(lsOver, lsOut)

    function lsOver() {
      if (s.stageBoxEntered && !$(this).hasClass('active')) {
        lifeStageBox.each(function() {
          console.log(this)
          if ($(this).hasClass('active')) {
            NF.lifeBoxLeaveTransition(this)
          }
        })
        lifeStageBox.removeClass('active')

        $(this).addClass('active')
        NF.lifeBoxActiveTransition(this)
      }

    }

    function lsOut() {

    }

  },

  // Affix
  affix() {
    let elems = $('.fix-ontop')
    elems.each(function() {
      let scrollController = new ScrollMagic.Controller(),
      trigger = $(this).data('trigger') || this,
      duration =  0,
      offset = $(this).data('offset') ? $(this).data('offset') : 0,
      hook = $(this).data('hook') ? $(this).data('hook') : 'onLeave'

      if($(this).data('duration')){
        if(typeof $(this).data('duration') === "string"){
          let elem = $($(this).data('duration'))
          duration = (elem.innerHeight() - $(this).innerHeight()) - 500
        } else {
          duration = $(this).data('duration')
        }
      }

      new ScrollMagic.Scene({ triggerElement: trigger, triggerHook: hook, duration: duration, offset: offset})
        .setPin(this)
        .setClassToggle(this,'fixed')
        .addTo(scrollController);

    })
  },

  // compare table
  compareTable() {
    let table = '#compare-table',
    tHead = '#compare-table-header',
    tFoot = '#compare-table-footer',
    controller = new ScrollMagic.Controller(),
    duration = $(table).innerHeight() - 400,
    durationFooter = $(table).innerHeight() - $(window).height()

    
    new ScrollMagic.Scene({ triggerElement: tHead, triggerHook: 'onLeave', duration: duration})
        .setPin(tHead)
        .addTo(controller);
    new ScrollMagic.Scene({ triggerElement: table, triggerHook: 'onLeave', duration: durationFooter})
        .setClassToggle(tFoot,'fix-footer')
        .addTo(controller);
  },
  scrollSpy() {
    let spyContainer = $('.scroll-spy'),
      spyItems = spyContainer.find('.spy-item'),
      scrollController = new ScrollMagic.Controller()

    spyItems.each(function() {
      let itemTarget = $(this).data('target')
      new ScrollMagic.Scene({ triggerElement: '#' + itemTarget, duration: $('#' + itemTarget).innerHeight() })
        .setClassToggle(this, 'active')
        .addTo(scrollController);
    })
  },
  // Side navigation trigger
  sideNavigationDropDown() {
    let triggerButton = $('.side-nav-trigger-button')

    triggerButton.on('click', onClick)

    function onClick(e) {
      e.preventDefault()

      if ($(this).hasClass('active')) {
        $(this).removeClass('active')
        closeSideNav(this)
      } else {
        $(this).addClass('active')
        openSideNav(this)
      }
    }

    function openSideNav(el) {
      let list = $(el).next()

      let tl = new TimelineMax();
      tl.to(list, 0.3, {
          scaleY: 1
        })
        .staggerTo(list.find('>li'), 0.5, {
          autoAlpha: 1,
          y: 0
        }, 0.05)
    }

    function closeSideNav(el) {
      let list = $(el).next()

      let tl = new TimelineMax();
      tl.staggerTo(list.find('>li'), 0.5, {
          autoAlpha: 0,
          y: -50,
          overwrite: 'all'
        }, 0.05)
        .to(list, 0.3, {
          scaleY: 0,
          overwrite: 'all'
        }, 0.3)
    }
  },
  // Pin trigger

  pinTrigger: function() {

    var controller = new ScrollMagic.Controller();

    $('.pin').each(function() {
      var pin = this;
      var target_top = $(pin).data('top');
      var offset = $(pin).data('offset') ? $(pin).data('offset') : -100;
      var duration = 0;
      if (!$(target_top).hasClass('windowHeight')) {
        duration = ($(target_top).outerHeight() / 2);
      } else {
        duration = $(window).height() - $(pin).outerHeight();
      }

      function updateBox(e) {

      };

      new ScrollMagic.Scene({ triggerElement: target_top, duration: duration, triggerHook: 'onLeave', offset: offset })
        .setPin(pin)
        .setClassToggle(pin, "pinned")
        .on("enter leave", updateBox)
        .addTo(controller);

    });
  },

  infoOVers() {
    let infoItems = $('.info-wrapper')

    infoItems.hover(function(){
      let panel = $(this).data('target') ? $(this).data('target') : false
      if(panel == false) return

        $(panel).addClass('active')
    }, function(){
      let panel = $(this).data('target') ? $(this).data('target') : false
      if(panel == false) return

        $(panel).removeClass('active')
    })
  },
  accordian() {
    let aTrigger = selectAll('.accordian-trigger'),
      aPanel = selectAll('.accordian-panel'),
      expandAll = $('.expand-all'),
      ease = 'swing',
      duration = 500,
      reset = function(wrapper) {
        let triggers = $(wrapper).find('.accordian-trigger'),
          panels = $(wrapper).find('.accordian-panel'),
          items = $(wrapper).find('.accordian-item')

        triggers.removeClass('active')
        items.removeClass('active')
        panels.removeClass('active')
        // panels.each(function() {
        //   TweenLite.to($(this), 0.8, { maxHeight: 0, ease: Power3.easeInOut })
        // })
        panels.slideUp(duration,ease)
      }
    // Searching for active panel
    aPanel.forEach(panel => {
      if (panel.classList.contains('active')) $(panel).show()
    })


    aTrigger.forEach(trigger => {
      trigger.addEventListener('click', function() {
        //reset()
        let panel = this.nextElementSibling
        if (this.classList.contains('active')) {
          this.classList.remove('active')
          $(this).closest('.accordian-item').removeClass('active')
          $(panel).removeClass('active')
          $(panel).slideUp(duration,ease)
        } else {
          reset($(this).closest('.accordian-wrapper'))
          let wrapperPanel = $(this).closest('.accordian-panel')
          this.classList.add('active')
          $(this).closest('.accordian-item').addClass('active')
          $(panel).addClass('active')
          $(panel).slideDown(duration,ease,function(){
            if($(trigger).hasClass('quick-link-title')){
              return
            }
            //$('html,body').animate({scrollTop: $(trigger).offset().top - 100},'fast')
          })
         //  TweenLite.to(panel, 0.8, { overwrite: "all", maxHeight: panel.scrollHeight, ease: Power3.easeInOut, onComplete: function(){
            
         //    if(wrapperPanel.length){
         //      console.log(wrapperPanel[0].scrollHeight)
         //      TweenLite.to(wrapperPanel,0.5,{overwrite: "all", maxHeight: wrapperPanel[0].scrollHeight})
         //    }
         //   } 
         // })
          
        }

      })
    })

    expandAll.on('click', function(e){
      e.preventDefault()

      let parentAccordianWrapper = $(this).closest('.accordian-wrapper')

      if($(this).hasClass('expand-all')){
        parentAccordianWrapper.find('.accordian-panel').slideDown(duration,ease).addClass('active')
        parentAccordianWrapper.find('.accordian-item').addClass('active')
        parentAccordianWrapper.find('.accordian-trigger').addClass('active')
        $(this).removeClass('expand-all').addClass('collapse-all').html('Collapse all')
      } else {
        parentAccordianWrapper.find('.accordian-panel').slideUp(duration,ease).removeClass('active')
        parentAccordianWrapper.find('.accordian-item').removeClass('active')
        parentAccordianWrapper.find('.accordian-trigger').removeClass('active')
        $(this).addClass('expand-all').removeClass('collapse-all').html('Expand all')
      }
      

      
    })


  },

  dateToday() {
    let date = new Date(),
    dateSpan = $('.date-today')

    

    dateSpan.html(date.toLocaleDateString(['en-US'],{month: 'long', day: 'numeric', year: 'numeric'}))

  },

  tableAccoridan() {
    let trigger = $('.table-cell[scope="row"]'),
        table = $('#compare-table'),
        tableRows = table.find('tr:not(.label-row)'),
        reset = function() {
          tableRows.removeClass('active')
          tableRows.find('td').slideUp()
        }

        tableRows.each(function() {
          if($(this).hasClass('active')){
            $(this).find('>td').show()
          }
        })

        trigger.on('click', function(){
          if(s.windowWidth > 1024){
           return
          }
           let parentRow = $(this).closest('tr'),
           elems = parentRow.find('>td')
           
           if(!parentRow.hasClass('active')){
            reset()
            parentRow.addClass('active')
            elems.slideDown()
           } else {
            parentRow.removeClass('active')
            elems.slideUp()
           }

        })

  }
}

export default NF
