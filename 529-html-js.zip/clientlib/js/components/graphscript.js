//import Highcharts from 'highcharts'
import { howToStartChartData } from './graphdata'
import { defaultOptionsWithoutCollege, getQucikResults } from "./getquickresults"


function select(s) {
  return document.querySelector(s)
}



(function(window) {

  'use strict';
  window.$childAge = 0
  Highcharts.Tooltip.prototype.pin = function() {
    this._hide = this.hide
    this.hide = function() {} // overriding hide function to nothing to remove mouseout tooltip hide
  }

  Highcharts.Point.prototype.highlight = function(event) {
    this.onMouseOver(); // Show the hover marker
    this.series.chart.tooltip.refresh(this); // Show the tooltip
    //this.series.chart.xAxis[0].drawCrosshair(event, this); // Show the crosshair
  };

  const SelectionGraph = function() {
    this.graphMaker = select('#howtostart-graph')
    this.graphContainer = select('#howtostart-graphContainer')
    this.amtSelect = this.graphMaker.querySelector('#select_amt')
    this.amt = this.amtSelect.value
    this.yearSelect = this.graphMaker.querySelector('#select_child_year')
    this.yearRangeSlider = select('#howtostart-slider')
    this.durationSelect = this.graphMaker.querySelector('#invest-duration')
    this.sliderLabelAgeSpan = select('#slider-label-max-age')
    this.childAge = 0
    //this.yearRangeInput =  select('#year-range-input')
    this.yearRangeLabelsHolder = this.graphMaker.querySelector('.range-labels')
    this.yearRangeLabels = this.graphMaker.querySelectorAll('.range-labels li')
    //this.yearHint = this.graphMaker.querySelector('#hint-year')
    //this.amtHint = this.graphMaker.querySelector('#hint-amount')
    this.savingsfromTodaySpan = this.graphMaker.querySelector('#savings-from-today-span')
    this.savingsXyearsSpan = this.graphMaker.querySelector('#savings-from-x-years-span')
    this.yearNumberSpan = this.graphMaker.querySelector('#year-number-span')
    this.percentageSpan = this.graphMaker.querySelector('#summary-info-span')
    this.selectGiftAmt = this.graphMaker.querySelector('#select_gift_amt')
    this.giftAmt = this.selectGiftAmt ? this.selectGiftAmt.value : 0 

    this.newParentCalc = 75794

    this.chart = null
    this.years = []
    this.resultOptions = defaultOptionsWithoutCollege
    //this.resultOptions.contributionAmount = this.amt
    this.resultOptions.stepType = "Dollars"
    //this.resultOptions.contributionAmount = 0

    this.resultOptions.stepAmount = parseInt(this.amt) + (parseInt(this.giftAmt) / 12)
    this.resultOptions.stepStartDate = this.startDateCalculator(0)
    //this.resultOptions.collegeName = ""
    this.resultOptions.collegeDuration = 1
    //this.resultOptions.institutionID = 0
    //this.resultOptions.includeContributionIncrease = true
    //this.resultOptions.currentAnnualCost = 18208

    this.totalAmount = null
    this.amountFromToday = null
    this.init()

    this.yData = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    this.apiCall = null
  }
  SelectionGraph.prototype = {
    init() {
      this.moneyFormat()
      if(this.graphContainer){
        this.setGraph()
      }
      this.setSlider()
      //this.setHint()
      this.yearChangeListener()
      //this.yearSliderInputListener()
      this.amtSelectListener()
      this.giftAmtListener()
      this.durationChangeListener()
      //this.calculateGraphData()
      setTimeout(() => {
        //this.callQuickResults()
        //this.updateGraphData()
      }, 500)


    },

    setGraph() {
      this.chart = Highcharts.chart(this.graphContainer, howToStartChartData)
      this.chart.update({
        xAxis: {
          categories: ['Today', 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17]
        }
      })
      //this.chart.series[0].setData(this.calculateGraphData(), true)
      this.chart.tooltip['pin']()
      //setTimeout(() => { this.chart.series[0].points[0].highlight() }, 1000)

    },

    callQuickResults() {
      return getQucikResults(this.resultOptions, (data) => {
        this.totalAmount = data.chartData.TotalSavings
        if(!this.amountFromToday)
        {
          this.amountFromToday = data.chartData.TotalSavings
        }
        if(this.graphContainer){
          this.updateGraphData()
          this.showTooltip(parseInt(this.yearRangeSlider.noUiSlider.get()))
        }
        
        this.updateYearData()
        
      })
      //this.updateGraphData()

    },

    getSimpleCalculatorYears() {
      let currentYear = 18 - this.childAge
      return currentYear + new Date().getFullYear()
    },
    toolTipFormatter (v){
      let childText = this.yearRangeSlider.dataset.text ? this.yearRangeSlider.dataset.text : 'child'
      let year = v,
          text = '',
          toolTipWrapper = ""

          switch (Math.round(v)) {
            case 0:
              text = 'a baby'
              break;
            case 1:
              text =  '1 year old'
              break;
            default:
              text = Math.round(v) + ' years old'
              break;
          }

          toolTipWrapper = "<div class='custom-tool-tip-wrapper'>" + 
      "<div class='tool-tip-body small text-primary-lighter ft-medium'>" +
         "When my " + childText +" is " + text +
      "</div>" +
      "</div>"
      
      return toolTipWrapper
    },
    setSlider(val) {
      noUiSlider.create(this.yearRangeSlider, {
        start: [val || 0],
        connect: true,
        step: 1,
        range: {
          'min': 0,
          'max': this.childAge == '17' ? 1 : 17 - this.childAge
        },
        tooltips: [{ to: (v) => this.toolTipFormatter(v) }]
      })

      this.onSlideHandler()
    },


    onSlideHandler() {
      let apiCall = { a: null, abort: null }
      this.yearRangeSlider.noUiSlider.on("update", () => {

        clearTimeout(apiCall.a)
        apiCall.abort ? apiCall.abort.abort() : null
        let sliderVal = this.yearRangeSlider.noUiSlider.get()

        $(this.yearNumberSpan).html(Math.round(sliderVal))

        apiCall.a = setTimeout(() => {
          // this.resultOptions.stepType = "Dollars"
          // this.resultOptions.contributionAmount = 0
          //this.resultOptions.stepAmount = this.amt
          this.resultOptions.stepStartDate = this.startDateCalculator(sliderVal)
          this.resultOptions.collegeStartYear = this.getSimpleCalculatorYears()
          apiCall.abort = this.callQuickResults()

        }, 250)

        //this.showTooltip(Math.round(sliderVal))


      });
    },

    startDateCalculator(sliderVal) {
      let currentDate = new Date(),
        month = currentDate.getMonth() + 1,
        year = currentDate.getFullYear()


      return (year + parseInt(sliderVal)) + '.' + month
    },

    updateSlider() {
      if (this.childAge > 18) return
      let age = this.yearRangeSlider.noUiSlider.get()
      this.yearRangeSlider.noUiSlider.destroy()
      this.setSlider(age)

      //let age = 18 - this.childAge

      
      //$(this.sliderLabelAgeSpan).html(age + ' years')
    },

    setHint() {
      let year = this.yearSelect.value === "0" ? 1 : this.yearSelect.value,
        amt = this.amt * year * 12
      //this.yearHint.innerHTML = year
      //this.amtHint.innerHTML = amt
    },

    yearChangeListener() {
      this.yearSelect.addEventListener("change", () => {
        //this.resetYdata()
        this.amountFromToday = null
        let yearVal = this.yearSelect.value
        this.childAge = yearVal
        window.$childAge = yearVal
        //this.yearRangeInput.value = yearVal

        this.resultOptions.age = this.childAge
        this.resultOptions.collegeStartYear = new Date().getFullYear() + 18 - parseInt(this.childAge)

        this.resultOptions.stepAmount = this.amt

        //this.callQuickResults()
        //this.setHint()
        //this.showTooltip()

        this.updateSlider()
      })
    },

    yearSliderInputListener() {
      this.yearRangeInput.addEventListener('input', () => {
        let yearVal = this.yearRangeInput.value
        this.yearSelect.value = yearVal

        this.setHint()
        this.showTooltip()
      })
    },

    amtSelectListener() {

      this.amtSelect.addEventListener('change', () => {
        //this.resetYdata()
        this.amountFromToday = null
        this.amt = this.amtSelect.value
        this.resultOptions.stepAmount = parseInt(this.amt) + (parseInt(this.giftAmt) / 12)
        //this.setHint()
        //this.updateGraphData()
        //this.showTooltip()
        //this.callQuickResults()
        this.updateSlider()
      })
    },

    giftAmtListener() {
        if(this.selectGiftAmt){
          this.selectGiftAmt.addEventListener('input', () => {
            this.amountFromToday = null
            this.giftAmt = this.selectGiftAmt.value
            this.resultOptions.stepAmount = parseInt(this.amt) + (parseInt(this.giftAmt) / 12)
            this.updateSlider()
          })
        }
    },

    durationChangeListener(){
      this.durationSelect.addEventListener('input', () => {
          this.resultOptions.contributionType = this.durationSelect.value

          this.updateSlider()
      })
    },

    // calculateGraphData () {
    //   // let data = this.years.map(year => {
    //   //   return this.amt * year * 12
    //   // })

    //   // return data

    //   let data = [],
    //       totalYears = 18
    //       //totalYears = this.getSimpleCalculatorYears()


    //   for (let i=0;i<=totalYears;i++){
    //     //let yearData = Math.round((this.totalAmount * i) / totalYears)
    //     let yearData = this.calculateSavings(this.amt, i)
    //     data.push(yearData)

    //   }
    //   return data
    // },

    calculateGraphData() {

      let sliderVal = parseInt(this.yearRangeSlider.noUiSlider.get())

      this.yData[sliderVal] = this.totalAmount

      return this.yData
    },
    calculateSavings(amount, yrs) {
      //return amount*( Math.pow((1 + 0.005), (12*yrs)) - 1 )/.005;
      return amount * (Math.pow((1 + (8 / 1200)), (12 * yrs)) - 1) / (8 / 1200);
    },

    // updateGraphData () {
    //   let years = [],
    //       totalYears = 18

    //   for (let i=0;i<=totalYears;i++){
    //     years.push(i)
    //   }
    //   this.years = years
    //   this.chart.update({
    //     xAxis: {
    //       categories:  years
    //     }
    //   })
    //   this.chart.series[0].setData(this.calculateGraphData(), true)
    // },
    updateGraphData() {
      let sliderVal = parseInt(this.yearRangeSlider.noUiSlider.get())
      //this.chart.series[0].setData(this.calculateGraphData(), true)
      let data = this.calculateGraphData().slice()
      this.chart.series[0].setData(data, true)

    },
    resetYdata() {
      for (let i = 0; i < 18; i++) {
        this.yData[i] = 0
      }

    },
    showTooltip(yearIndex) {
      let chart = this.chart,
        xAxis = chart.xAxis[0],
        // yearIndex = this.years.findIndex(year => {
        //   // if(parseInt(this.yearSelect.value)){
        //   //   return year === parseInt(this.yearSelect.value)
        //   // }
        //   // return 1

        //   return year === parseInt(this.yearSelect.value)
        // }),
        tooltipPoint = chart.series[0].points[yearIndex]

      if (tooltipPoint === undefined) return
      //console.log(yearIndex)
      //chart.tooltip.refresh(tooltipPoint)
      tooltipPoint.highlight()
    },

    updateYearData() {
      let formatedAmount = parseInt(this.totalAmount).formatMoney(0),
          formatedAmountFromToday = parseInt(this.amountFromToday).formatMoney(0),
          percentageValue = (this.totalAmount / this.newParentCalc) * 100
          
      $(this.savingsXyearsSpan).html(formatedAmount)
      $(this.savingsfromTodaySpan).html(formatedAmountFromToday)
      if(percentageValue > 100){
        $(this.percentageSpan).html("That's <span class='medium'>100% </span> of what you'll need for four years of <br>in-state tuition." )
       } else if (percentageValue < 10) {
         $(this.percentageSpan).html("That's less than <span class='medium'> 1% </span> of what you'll need for four years of <br>in-state tuition." )
       } else {
         $(this.percentageSpan).html("That's about <span class='medium'>" + Math.round(percentageValue) + "% </span> of what you'll need for four years of <br>in-state tuition." )
       }
     
    },

    moneyFormat() {
      Number.prototype.formatMoney = function(c, d, t) {
        var n = this,
          c = isNaN(c = Math.abs(c)) ? 2 : c,
          d = d == undefined ? "." : d,
          t = t == undefined ? "," : t,
          s = n < 0 ? "-" : "",
          i = String(parseInt(n = Math.abs(Number(n) || 0).toFixed(c))),
          j = (j = i.length) > 3 ? j % 3 : 0;
        return s + '$ ' + (j ? i.substr(0, j) + t : "") + i.substr(j).replace(/(\d{3})(?=\d)/g, "$1" + t) + (c ? d + Math.abs(n - i).toFixed(c).slice(2) : "");
      }
    }
  }

  let simpleGraphLoaded = false
  if (select('#howtostart-graph')) {
    new SelectionGraph()
    // select('.howtostart-graphTab').addEventListener('click', () => {
    //   if(!simpleGraphLoaded) {
    //     new SelectionGraph()
    //     simpleGraphLoaded = true
    //   }
    // })


  }

})(window)
