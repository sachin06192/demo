; (function () {

    function DropDown(el) {
        this.dd = el;
        this.placeholder = this.dd.children('span');
        this.opts = this.dd.find('.tab-links ul > li a');
        this.val = '';
        this.index = -1;
        this.initEvents();
    }

    DropDown.prototype = {
        initEvents: function () {
            var obj = this;

            obj.dd.on('click', function (event) {
                $(this).toggleClass('active');
                return false;
            });

            obj.opts.on('click', function () {
                var opt = $(this);
                obj.val = opt.text();
                obj.index = opt.index();
                obj.placeholder.text(obj.val);
            });
        },
        getValue: function () {
            return this.val;
        },
        getIndex: function () {
            return this.index;
        }
    }

    $(function () {

        if ($(window).width() < 768) {
            let tabDDs = $('.tab-wrapper .tab-links');
            // console.log(tabDDs);
            for (let i = 0; i < tabDDs.length; i++) {
                let tabDD = 'tabDD' + i;
                let thisEl = $(tabDDs[i]);
                // console.log(thisEl);
                let placeholder = thisEl.find('li.active a').text();
                // console.log(placeholder)
                thisEl.prepend('<span>' + placeholder + '</span>')
                tabDD = new DropDown(thisEl);
                // console.log(tabDD)
            }

            $(document).click(function () {
                // Hide all tab dropdowns
                $('.tab-links').removeClass('active');
            });

            tabDDs.on('click', '.tab-link a', function () {
                $(this).closest('.tab-links').children('span').text($(this).text());
            });
        }
    });
})();
