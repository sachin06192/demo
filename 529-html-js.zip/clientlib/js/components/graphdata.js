// export default {
//   chart: {
//     type: 'areaspline'
//   },
//   title: {
//     text: ''
//   },
//   // legend: {
//   //   layout: 'vertical',
//   //   align: 'left',
//   //   verticalAlign: 'top',
//   //   x: 150,
//   //   y: 100,
//   //   floating: true,
//   //   borderWidth: 1,
//   //   backgroundColor: (Highcharts.theme && Highcharts.theme.legendBackgroundColor) || '#FFFFFF'
//   // },
//   xAxis: {
//     lineWidth: 1,
//     lineColor: '#000',
//     tickLength: 0,
//     crosshair: {
//       enabled: true
//     }
//     // categories: [
//     //   '1',
//     //   '5',
//     //   '10',
//     //   '15',
//     //   '20'
//     // ]
//   },
//   yAxis: {
//     // title: {
//     //   tickWidth: 0
//     // }
//     tickWidth: 0,
//     //crosshair: false,
//     lineWidth: 1,
//     lineColor: '#000',
//     gridLineWidth: 0,
//     labels: {
//       enabled: false
//     },
//     opposite: true
//   },
//   tooltip: {
//     shared: false,
//     followPointer: false,
//     valueSuffix: '$',
//     useHTML: true,
//     formatter() {
//       //  By the time your child is X years old, you would have already covered his 1st year of tuition.
//       return "By the time your child is <strong>" + this.x + " years</strong> old, you would have already covered his <strong>" + this.y + "</strong> year of tuition."
//     }
//   },
//   plotOptions: {
//     fillColor: {
//       linearGradient: {
//         x1: 0,
//         y1: 0,
//         x2: 0,
//         y2: 1
//       },
//       stops: [
//         [0, Highcharts.getOptions().colors[0]],
//         [1, Highcharts.Color(Highcharts.getOptions().colors[0]).setOpacity(0).get('rgba')]
//       ]
//     },
//     areaspline: {
//       color: '#1862a1',
//       fillOpacity: 0.5,
//       lineWidth: 1,
//       lineColor: '#000',
//       stickyTracking: false
//     }
//   },
//   credits: {
//     enabled: false
//   },
//   // series: [{
//   //   name: 'Year',

//   // }],
//   series: [{
//     name: '',
//     data: [
//       [0, 1],
//       [1, 2],
//       [5, 3],
//       [10, 4],
//       [15, 5],
//       [20, 6]
//     ]
//   }]
// }

export const howToStartChartData = {
  chart: {
    type: 'areaspline'
  },
  title: {
    text: ''
  },
  xAxis: {
    title: {
      enabled: true,
      text: 'When(yrs)'
    },
    lineWidth: 1,
    lineColor: '#000',
    tickLength: 0,
    crosshair: {
      enabled: false
    }
  },
  yAxis: {
    tickWidth: 0,
    //crosshair: false,
    lineWidth: 1,
    lineColor: '#005f9e',
    gridLineWidth: 0,
    labels: {
      enabled: false
    },
    opposite: true
  },
  tooltip: {
    shared: false,
    followPointer: false,
    backgroundColor: '#fff',
    borderColor: '#fff',
    valueSuffix: '$',
    useHTML: true,
    formatter() {
      // return "<span class='tooltip-custom'>By the time your child is <strong>" +  (parseInt($childAge) + parseInt(this.x)) + " years</strong> old, you would have already covered his tuition fee worth <strong>" + this.y.formatMoney(0) + "</strong></span>"
      return "<span class='tooltip-custom'><strong>" + this.y.formatMoney(0) + "</strong></span>"
    }
  },
  plotOptions: {
    column: {
      color: '#005f9e',
      fillOpacity: 0.5,
      lineWidth: 1,
      lineColor: '#005f9e',
      stickyTracking: false,
      fillColor: {
        linearGradient: {
          x1: 0,
          y1: 0,
          x2: 0,
          y2: 1
        },
        stops: [
          [0, '#97c5f0'],
          [1, 'rgba(151, 197, 240, 0.2)']
        ]
      },
      pointWidth: 10
    }
  },
  credits: {
    enabled: false
  },
  series: [{
    name: '1st child'
  }]
};


export const boostingContributionChartData = {
  chart: {
    type: 'column',
    
  },
  title: {
    text: ''
  },
  xAxis: {
    title: {
      enabled: true,
      text: 'After 18 years'
    },
    lineWidth: 1,
    lineColor: '#000',
    tickLength: 0,
    crosshair: {
      enabled: false
    },
    labels: {
      enabled: false
    }
  },
  yAxis: {
    tickWidth: 0,
    //crosshair: false,
    lineWidth: 1,
    lineColor: '#005f9e',
    gridLineWidth: 0,
    labels: {
      enabled: false
    },
    opposite: true
  },
  tooltip: {
    enabled: false,
    shared: false,
    followPointer: false,
    backgroundColor: '#fff',
    borderColor: '#fff',
    valueSuffix: '$',
    useHTML: true,
    formatter() {
      // return "<span class='tooltip-custom'>By the time your child is <strong>" +  (parseInt($childAge) + parseInt(this.x)) + " years</strong> old, you would have already covered his tuition fee worth <strong>" + this.y.formatMoney(0) + "</strong></span>"
      return "<span class='bold'>" + this.series.name + "</span>" +
      "<span class='tooltip-custom'><strong>" + this.y.formatMoney(0) + "</strong></span>"
    },
    positioner: function (labelWidth, labelHeight, point) {
            return { 
              x: 10,
              y: 10
            }
    },
  },
  legend: {
        align: 'right',
        x: 0,
        verticalAlign: 'top',
        y: -30,
        floating: true,
        backgroundColor: 'transparent',
        borderColor: 'transparent',
        borderWidth: 1,
        shadow: false
  },
  plotOptions: {
    areaspline: {
      color: '#005f9e',
      fillOpacity: 0.5,
      lineWidth: 1,
      lineColor: '#005f9e',
      stickyTracking: false,
      fillColor: {
        linearGradient: {
          x1: 0,
          y1: 0,
          x2: 0,
          y2: 1
        },
        stops: [
          [0, '#97c5f0'],
          [1, 'rgba(151, 197, 240, 0.2)']
        ]
      }
    },
    column: {           
        groupPadding: 0.5,
        pointWidth: 120                                  
    }
  },
  credits: {
    enabled: false
  },
  series: [{
    name: 'With gifts'
  },{
    name: 'Without gifts'
  }]
};

export const boostingContributionChartDataB = {
  chart: {
    type: 'column'
  },
  title: {
    text: ''
  },
  xAxis: {
    title: {
      enabled: true,
      text: 'After 18 years'
    },
    lineWidth: 1,
    lineColor: '#000',
    tickLength: 0,
    crosshair: {
      enabled: false
    },
    labels: {
      enabled: false
    }
  },
  yAxis: {
    tickWidth: 0,
    //crosshair: false,
    lineWidth: 1,
    lineColor: '#005f9e',
    gridLineWidth: 0,
    labels: {
      enabled: false
    },
    opposite: true
  },
  tooltip: {
    enabled: true,
    shared: false,
    followPointer: false,
    backgroundColor: '#fff',
    borderColor: '#fff',
    valueSuffix: '$',
    useHTML: true,
    formatter() {
      // return "<span class='tooltip-custom'>By the time your child is <strong>" +  (parseInt($childAge) + parseInt(this.x)) + " years</strong> old, you would have already covered his tuition fee worth <strong>" + this.y.formatMoney(0) + "</strong></span>"
      return "<span class='bold'>" + this.series.name + "</span>" +
      "<span class='tooltip-custom'><strong>" + this.y.formatMoney(0) + "</strong></span>"
    }
  },
  plotOptions: {
    areaspline: {
      color: '#005f9e',
      fillOpacity: 0.5,
      lineWidth: 1,
      lineColor: '#005f9e',
      stickyTracking: false,
      fillColor: {
        linearGradient: {
          x1: 0,
          y1: 0,
          x2: 0,
          y2: 1
        },
        stops: [
          [0, '#97c5f0'],
          [1, 'rgba(151, 197, 240, 0.2)']
        ]
      }
    }
  },
  credits: {
    enabled: false
  },
  series: [{
    name: 'Without gifts',
    color: "rgb(92,92,97)"
  },{
    name: 'With gifts'
  }]
};

export const twoChildGraph = {
  chart: {
    type: 'areaspline'
  },
  title: {
    text: ''
  },
  xAxis: {
    lineWidth: 1,
    lineColor: '#000',
    tickLength: 0,
    crosshair: {
      enabled: true
    },
    categories: [
      '0',
      '5',
      '10',
      '15',
      '20'
    ]
  },
  yAxis: {
    // title: {
    //   tickWidth: 0
    // }
    tickWidth: 0,
    //crosshair: false,
    lineWidth: 1,
    lineColor: '#000',
    gridLineWidth: 0,
    labels: {
      enabled: false
    },
    opposite: true
  },
  tooltip: {
    shared: false,
    followPointer: false,
    valueSuffix: '$',
    useHTML: true,
    formatter() {
      return "By the time your child is <strong>" + this.x + " years</strong> old, you would have already covered his <strong>" + this.y + "</strong> year of tuition."
    }
  },
  plotOptions: {
    areaspline: {
      color: '#005f9e',
      fillOpacity: 0.5,
      lineWidth: 1,
      lineColor: '#005f9e',
      stickyTracking: false,
      fillColor: {
        linearGradient: {
          x1: 0,
          y1: 0,
          x2: 0,
          y2: 1
        },
        stops: [
          [0, '#97c5f0'],
          [1, 'rgba(151, 197, 240, 0.2)']
        ]
      }
    }
  },
  credits: {
    enabled: false
  },
  series: [{
    name: '1st child',
    data: [0, 2, 6, 12, 20]
  }, {
    name: '2nd child',
    data: [0, 1, 3, 6, 10]
  }]
};



// $('.howtostart-graphTab').one('click', function () {
//   Highcharts.chart(document.querySelector('#twoChildGraph'), howToStartChart);
//   let toolTipFirst = howToStartChart.series[0].points[0]
//   // twoChildGraphTooltip_one = twoChildGraph.series[0].points[0],
//   // twoChildGraphTooltip_two = twoChildGraph.series[1].points[0];

//   howToStartChart.tooltip.refresh(toolTipFirst)
//   // twoChildGraph.tooltip.refresh(twoChildGraphTooltip_one)
//   // twoChildGraph.tooltip.refresh(twoChildGraphTooltip_two)
// });

// $('.howtostart-graphTab').one('click', function () {
//   Highcharts.chart(document.querySelector('#twoChildGraph'), twoChildGraph)
// });

// if (document.querySelector('#howtostart-graphContainer')) {
//   Highcharts.chart(document.querySelector('#howtostart-graphContainer'), howToStartChart)
// }

if (document.querySelector('#twoChildGraph')) {
  Highcharts.chart(document.querySelector('#twoChildGraph'), twoChildGraph)
}

if (document.querySelector('#simpleCalculatorContainer')) {
  //Highcharts.chart(document.querySelector('#simpleCalculatorContainer'), howToStartChart)
}

// Highcharts.chart(document.querySelector('#twoChildGraph'), twoChildGraph)

function semester (year) {
  let text = ''
  switch (year) {
    case 4: text = "2nd"
    break
    case 8: text = "4th"
    break
    case 12: text = "6th"
    break
    case 16: text = "8th"
    break
    case 20: text = "10th"
    break
    default: text = 0
    break
  }

  return text
}