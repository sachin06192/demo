//import Highcharts from 'highcharts'
import { boostingContributionChartData, boostingContributionChartDataB } from './graphdata'
import { defaultOptionsWithoutCollege, getQucikResults } from "./getquickresults"



function select(s) {
  return document.querySelector(s)
}



(function(window) {

  'use strict';
  window.$childAge = 0
  Highcharts.Tooltip.prototype.pin = function() {
    this._hide = this.hide
    this.hide = function() {} // overriding hide function to nothing to remove mouseout tooltip hide
  }

  Highcharts.Point.prototype.highlight = function(event) {
    this.onMouseOver(); // Show the hover marker
    this.series.chart.tooltip.refresh(this); // Show the tooltip
    //this.series.chart.xAxis[0].drawCrosshair(event, this); // Show the crosshair
  };

  const SelectionGraph = function() {
    this.graphMaker = select('#howtostart-graph-b')
    this.graphContainer = select('#howtostart-graphContainer', this.graphMaker)
    this.amtSelect = this.graphMaker.querySelector('#select_amt', this.graphMaker)
    this.amt = this.amtSelect.value
    this.yearSelect = this.graphMaker.querySelector('#select_child_year', this.graphMaker)
    this.yearRangeSlider = select('#howtostart-slider', this.graphMaker)
    this.durationSelect = this.graphMaker.querySelector('#invest-duration', this.graphMaker)
    this.sliderLabelAgeSpan = select('#slider-label-max-age', this.graphMaker)
    this.childAge = 0
    //this.yearRangeInput =  select('#year-range-input')
    this.yearRangeLabelsHolder = this.graphMaker.querySelector('.range-labels', this.graphMaker)
    this.yearRangeLabels = this.graphMaker.querySelectorAll('.range-labels li', this.graphMaker)
    //this.yearHint = this.graphMaker.querySelector('#hint-year')
    //this.amtHint = this.graphMaker.querySelector('#hint-amount')
    this.savingsfromTodaySpan = this.graphMaker.querySelectorAll('.result-amt-with-gift')
    this.resultAmtWithoutGiftSpan = this.graphMaker.querySelectorAll('.result-amt-without-gift')
    this.savingsXyearsSpan = this.graphMaker.querySelector('#savings-from-x-years-span')
    this.yearNumberSpan = this.graphMaker.querySelector('#year-number-span')
    this.percentageSpan = this.graphMaker.querySelector('#summary-info-span')
    this.selectGiftAmt = this.graphMaker.querySelector('#select_gift_amt')
    this.monthylyAmtSpan = this.graphMaker.querySelectorAll('.monthly-amt')
    this.giftAmtSpan = select('.gift-amt', this.graphMaker)
    this.amtDifferSpan = select('.amt-difference', this.graphMaker)


    this.giftAmt = this.selectGiftAmt ? this.selectGiftAmt.value : 0

    this.newParentCalc = 75794

    this.chart = null
    this.years = []
    this.resultOptions = defaultOptionsWithoutCollege
    //this.resultOptions.contributionAmount = this.amt
    this.resultOptions.stepType = "Dollars"
    //this.resultOptions.contributionAmount = 0

    this.resultOptions.stepAmount = parseInt(this.amt) + (parseInt(this.giftAmt) / 12)
    this.resultOptions.stepStartDate = this.startDateCalculator(0)
    //this.resultOptions.collegeName = ""
    this.resultOptions.collegeDuration = 1
    //this.resultOptions.institutionID = 0
    //this.resultOptions.includeContributionIncrease = true
    //this.resultOptions.currentAnnualCost = 18208

    this.totalAmount = 0
    this.amountFromToday = 0
    this.amountFromTodayWithoutGift = 0
    this.init()

    this.yData = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    this.apiCall = null
  }
  SelectionGraph.prototype = {
    init() {
      this.moneyFormat()
      if (this.graphContainer) {
        this.setGraph()
      }
      this.setSlider()
      //this.setHint()
      this.yearChangeListener()
      //this.yearSliderInputListener()
      this.amtSelectListener()
      this.giftAmtListener()
      this.durationChangeListener()
      //this.calculateGraphData()
      setTimeout(() => {
        //this.callQuickResults()
        //this.updateGraphData()
      }, 500)


    },

    setGraph() {
      let chartOptions
      if($(this.graphMaker).data('side-by-side-col') === true){
        chartOptions = boostingContributionChartDataB
      } else {
        chartOptions = boostingContributionChartData
      }
      this.chart = Highcharts.chart(this.graphContainer, chartOptions)
      this.chart.update({
        xAxis: {
          categories: [2036]
        }
      })
      //this.chart.series[0].setData(this.calculateGraphData(), true)
      this.chart.tooltip['pin']()
      //setTimeout(() => { this.chart.series[0].points[0].highlight() }, 1000)

    },

    callQuickResults(noSpread) {
      return getQucikResults(this.resultOptions, (data) => {
        if (noSpread) { // for graphs without gift
          this.amountFromTodayWithoutGift = data.chartData.TotalSavings
          if (this.graphContainer) {
            this.updateGraphData()
            this.showTooltip(parseInt(this.yearRangeSlider.noUiSlider.get()))
          }
          this.updateYearData()
          this.htmlUpdates()
          return
        }

        // for graphs with gift
        this.totalAmount = data.chartData.TotalSavings
        if (!this.amountFromToday) {
          this.amountFromToday = data.chartData.TotalSavings
        }
        if (this.graphContainer) {
          this.updateGraphData()
          this.showTooltip(parseInt(this.yearRangeSlider.noUiSlider.get()))
        }

        this.updateYearData()
        this.htmlUpdates()
      })
      //this.updateGraphData()

    },

    getSimpleCalculatorYears() {
      let currentYear = 18 - this.childAge
      return currentYear + new Date().getFullYear()
    },
    toolTipFormatter(v) {
      let childText = this.yearRangeSlider.dataset.text ? this.yearRangeSlider.dataset.text : 'child'
      let year = v,
        text = Math.round(v) > 1 ? Math.round(v) + ' years' : Math.round(v) + ' year',
        toolTipWrapper = "<div class='custom-tool-tip-wrapper'>" +
        "<div class='tool-tip-body small text-primary-lighter ft-medium'>" +
        "When my " + childText + " is " + text + " old" +
        "</div>" +
        "</div>"

      return toolTipWrapper
    },
    setSlider() {
      noUiSlider.create(this.yearRangeSlider, {
        start: [0],
        connect: true,
        step: 1,
        range: {
          'min': 0,
          'max': this.childAge == '17' ? 1 : 17 - this.childAge
        },
        tooltips: [{ to: (v) => this.toolTipFormatter(v) }]
      })

      this.onSlideHandler()
    },


    onSlideHandler() {
      let apiCall = { a: null, abort: null }
      this.yearRangeSlider.noUiSlider.on("update", () => {

        clearTimeout(apiCall.a)
        apiCall.callingResults ? apiCall.callingResults.abort() : null
        apiCall.callingResultsWithoutGift ? apiCall.callingResultsWithoutGift.abort() : null
        let sliderVal = this.yearRangeSlider.noUiSlider.get()

        $(this.yearNumberSpan).html(Math.round(sliderVal))

        apiCall.a = setTimeout(() => {
          // this.resultOptions.stepType = "Dollars"
          // this.resultOptions.contributionAmount = 0
          //this.resultOptions.stepAmount = this.amt
          this.resultOptions.stepStartDate = this.startDateCalculator(sliderVal)
          this.resultOptions.collegeStartYear = this.getSimpleCalculatorYears()
          apiCall.callingResults = this.callQuickResults()
          // calling results without gift
          this.resultOptions.stepAmount = this.amt
          apiCall.callingResultsWithoutGift = this.callQuickResults(true)
        }, 250)

        //this.showTooltip(Math.round(sliderVal))


      });
    },

    startDateCalculator(sliderVal) {
      let currentDate = new Date(),
        month = currentDate.getMonth() + 1,
        year = currentDate.getFullYear()


      return (year + parseInt(sliderVal)) + '.' + month
    },

    updateSlider() {
      if (this.childAge > 18) return
      this.yearRangeSlider.noUiSlider.destroy()
      this.setSlider()

      let age = 18 - this.childAge


      //$(this.sliderLabelAgeSpan).html(age + ' years')
    },

    setHint() {
      let year = this.yearSelect.value === "0" ? 1 : this.yearSelect.value,
        amt = this.amt * year * 12
      //this.yearHint.innerHTML = year
      //this.amtHint.innerHTML = amt
    },

    yearChangeListener() {
      this.yearSelect.addEventListener("change", () => {
        //this.resetYdata()
        this.amountFromToday = null
        let yearVal = this.yearSelect.value
        this.childAge = yearVal
        window.$childAge = yearVal
        //this.yearRangeInput.value = yearVal

        this.resultOptions.age = this.childAge
        this.resultOptions.collegeStartYear = new Date().getFullYear() + 18 - parseInt(this.childAge)

        this.resultOptions.stepAmount = this.amt

        //this.callQuickResults()
        //this.setHint()
        //this.showTooltip()

        this.updateSlider()
      })
    },

    yearSliderInputListener() {
      this.yearRangeInput.addEventListener('input', () => {
        let yearVal = this.yearRangeInput.value
        this.yearSelect.value = yearVal

        this.setHint()
        this.showTooltip()
      })
    },

    amtSelectListener() {

      this.amtSelect.addEventListener('change', () => {
        //this.resetYdata()
        this.amountFromToday = null
        this.amt = this.amtSelect.value
        this.resultOptions.stepAmount = parseInt(this.amt) + (parseInt(this.giftAmt) / 12)
        //this.setHint()
        //this.updateGraphData()
        //this.showTooltip()
        //this.callQuickResults()
        this.updateSlider()
      })
    },

    giftAmtListener() {
      if (this.selectGiftAmt) {
        this.selectGiftAmt.addEventListener('change', () => {
          this.amountFromToday = null
          this.giftAmt = this.selectGiftAmt.value
          this.resultOptions.stepAmount = parseInt(this.amt) + (parseInt(this.giftAmt) / 12)
          this.updateSlider()
        })
      }
    },

    durationChangeListener() {
      this.durationSelect.addEventListener('input', () => {
        this.resultOptions.contributionType = this.durationSelect.value

        this.updateSlider()
      })
    },

    calculateGraphData() {
      // let data = this.years.map(year => {
      //   return this.amt * year * 12
      // })

      // return data

      let data = []
      //totalYears = this.getSimpleCalculatorYears()

      data.push({
        y: this.totalAmount,
        dataLabels: {
          enabled: true,
          formatter: () => {
            return this.totalAmount.formatMoney(0)
          }
        }
      })


      return data
    },

    calculateGraphDataWithoutGift() {
      let data = []
      //totalYears = this.getSimpleCalculatorYears()

      data.push({
        y: this.amountFromTodayWithoutGift,
        dataLabels: {
          enabled: true,
          formatter: () => {
            return this.amountFromTodayWithoutGift.formatMoney(0)
          }
        }
      })
      return data
    },

    // calculateGraphData() {

    //   let sliderVal = parseInt(this.yearRangeSlider.noUiSlider.get())

    //   this.yData[sliderVal] = this.totalAmount

    //   return this.yData
    // },
    // calculateSavings(amount, yrs) {
    //   //return amount*( Math.pow((1 + 0.005), (12*yrs)) - 1 )/.005;
    //   return amount * (Math.pow((1 + (8 / 1200)), (12 * yrs)) - 1) / (8 / 1200);
    // },

    calculateSavings(amount, yrs) {
      console.log(amount / yrs)
      return amount / 2;
    },

    // updateGraphData () {
    //   let years = [],
    //       totalYears = 18

    //   for (let i=0;i<=totalYears;i++){
    //     years.push(i)
    //   }
    //   this.years = years
    //   this.chart.update({
    //     xAxis: {
    //       categories:  years
    //     }
    //   })
    //   this.chart.series[0].setData(this.calculateGraphData(), true)
    // },
    updateGraphData() {
      let sliderVal = parseInt(this.yearRangeSlider.noUiSlider.get())
      //this.chart.series[0].setData(this.calculateGraphData(), true)
      let data = this.calculateGraphData().slice()
      let dataWithoutGifts = this.calculateGraphDataWithoutGift().slice()
      if($(this.graphMaker).data('side-by-side-col') === true){
         this.chart.series[1].setData(data, true)
         this.chart.series[0].setData(dataWithoutGifts, true)
      } else {
         this.chart.series[0].setData(data, true)
         this.chart.series[1].setData(dataWithoutGifts, true)
      }
      
    },
    resetYdata() {
      for (let i = 0; i < 18; i++) {
        this.yData[i] = 0
      }

    },
    showTooltip(yearIndex) {
      let chart = this.chart,
        xAxis = chart.xAxis[0],
        // yearIndex = this.years.findIndex(year => {
        //   // if(parseInt(this.yearSelect.value)){
        //   //   return year === parseInt(this.yearSelect.value)
        //   // }
        //   // return 1

        //   return year === parseInt(this.yearSelect.value)
        // }),
        tooltipPoint = chart.series[0].points[yearIndex],
        tooltipPoint2 = chart.series[1].points[yearIndex]

      if (tooltipPoint === undefined) return
      //console.log(yearIndex)
      //chart.tooltip.refresh(tooltipPoint)
      tooltipPoint.highlight()
      tooltipPoint2.highlight()
    },

    updateYearData() {
      let formatedAmount = parseInt(this.totalAmount).formatMoney(0),
        formatedAmountFromToday = parseInt(this.amountFromToday).formatMoney(0),
        formatedAmountFromTodayWithoutGift = parseInt(this.amountFromTodayWithoutGift).formatMoney(0),
        formatedAmountDiffer = parseInt((this.amountFromToday - this.amountFromTodayWithoutGift)).formatMoney(0),
        percentageValue = (this.totalAmount / this.newParentCalc) * 100



      $(this.savingsXyearsSpan).html(formatedAmount)
      $(this.savingsfromTodaySpan).html(formatedAmountFromToday)
      $(this.resultAmtWithoutGiftSpan).html(formatedAmountFromTodayWithoutGift)
      $(this.amtDifferSpan).html(formatedAmountDiffer)
      if (percentageValue > 100) {
        $(this.percentageSpan).html("That's <span class='medium'>100% </span> of what you'll need for 4 years of in-state tuition and expenses.*")
      } else if (percentageValue < 10) {
        $(this.percentageSpan).html("That's less than <span class='medium'> 1% </span> of what you'll need for 4 years of in-state tuition and expenses.*")
      } else {
        $(this.percentageSpan).html("That's about <span class='medium'>" + Math.round(percentageValue) + "% </span> of what you'll need for 4 years of in-state tuition and expenses.*")
      }

    },

    htmlUpdates() {
      let amtDiffer =
        $(this.monthylyAmtSpan).html(parseInt(this.amt).formatMoney(0))
      $(this.giftAmtSpan).html(parseInt(this.giftAmt).formatMoney(0))

      //console.log()
    },

    moneyFormat() {
      Number.prototype.formatMoney = function(c, d, t) {
        var n = this,
          c = isNaN(c = Math.abs(c)) ? 2 : c,
          d = d == undefined ? "." : d,
          t = t == undefined ? "," : t,
          s = n < 0 ? "-" : "",
          i = String(parseInt(n = Math.abs(Number(n) || 0).toFixed(c))),
          j = (j = i.length) > 3 ? j % 3 : 0;
        return s + '$ ' + (j ? i.substr(0, j) + t : "") + i.substr(j).replace(/(\d{3})(?=\d)/g, "$1" + t) + (c ? d + Math.abs(n - i).toFixed(c).slice(2) : "");
      }
    }
  }

  let simpleGraphLoaded = false
  if (select('#howtostart-graph-b')) {
    new SelectionGraph()
    // select('.howtostart-graphTab').addEventListener('click', () => {
    //   if(!simpleGraphLoaded) {
    //     new SelectionGraph()
    //     simpleGraphLoaded = true
    //   }
    // })


  }

})(window)
