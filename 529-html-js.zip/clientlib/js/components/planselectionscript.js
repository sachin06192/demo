export const bannerSlider = function() {
  this.selectionArea = document.querySelector(".plan-selection-area")
  this.sliderNavs = document.querySelectorAll("a.slide-nav");
  this.slides = document.querySelectorAll(".illustration");
  this.circleNav = document.querySelector("#circle-nav");
  this.circleRail = document.querySelector("#circle-nav-rail circle");
  this.circleDots = document.querySelectorAll("#circle-nav-dots circle");
  this.mainTimeLine = null;
  this.slideDelay = 8;
  this.paused = false;
  this.init();
};

bannerSlider.prototype = {
  init() {
    //this.disappearCircles()
    //this.entryTimeline()
    if (this.paused) {
      this.tab();
    } else {
      this.addMainTimeline();
      this.sliderNavigation();
    }

    // /this.resize()
  },

  disappearCircles() {
    const circleDots = this.circleDots;
    const circleRail = this.circleRail;

    // circleDots.forEach(dot => {
    // 	dot.style.strokeDasharray = dot.getTotalLength()
    // 	dot.style.strokeDashoffset = dot.getTotalLength()
    // 	dot.dataset.strokeoffset = dot.getTotalLength()
    // })

    circleRail.style.strokeDasharray = circleRail.getTotalLength();
    circleRail.style.strokeDashoffset = circleRail.getTotalLength();
    circleRail.dataset.strokeoffset = circleRail.getTotalLength();
  },

  entryTimeline() {
    let tl = new TimelineMax({
        delay: 0,
        onComplete: () => {
          this.mainTimeLine.play();
        }
      }),
      controller = new ScrollMagic.Controller();

    tl.to(this.circleRail, 0.5, {
      strokeDashoffset: 0,
      //strokeDasharray: "5.006 5.006",
      transformOrigin: "50% 50%"
    })
      .staggerFrom(
        this.circleDots,
        0.5,
        {
          scale: 0,
          transformOrigin: "50% 50%",
          ease: Back.easeOut.config(1.7)
        },
        0.1,
        0.5
      )
      .to(this.circleRail, 0.5, { strokeDasharray: "5.006 5.006" });

    new ScrollMagic.Scene({
      triggerElement: this.circleNav,
      duration: 0,
      triggerHook: "onCenter",
      offset: -200
    })
      .setTween(tl)
      .addTo(controller);
  },

  tab() {
    this.slides.forEach(slide => {
      TweenLite.set(slide, { autoAlpha: 0 });
    });
    this.sliderNavs[0].classList.add("active");
    TweenLite.to(this.slides[0], 0.5, { autoAlpha: 1 });

    function resetSlider(navs, slides) {
      navs.forEach(nav => {
        nav.classList.remove("active");
      });

      slides.forEach(slide => {
        TweenLite.to(slide, 0.2, { autoAlpha: 0, overwrite: "all" });
      });
    }
    this.sliderNavs.forEach(nav => {
      let navs = this.sliderNavs,
        slides = this.slides;
      nav.addEventListener("click", e => {
        e.preventDefault();

        $('html,body').animate({scrollTop: $(this.selectionArea).offset().top - 200})
        resetSlider(navs, slides);

        let target = nav.dataset.slide;

        nav.classList.add("active");
        TweenLite.to("#" + target, 0.5, { autoAlpha: 1, delay: 0.5 });
      });
    });
  },
  addMainTimeline() {
    let tl = new TimelineMax({ repeat: -1 });

    this.slides.forEach(slide => {
      let slideItems = slide.children;
      tl.from(slide, 0.2, { autoAlpha: 0 }, slide.id)
        .staggerFrom(
          slideItems,
          0.2,
          {
            autoAlpha: 0
            //y: 100,
          },
          0,
          slide.id
        )
        .staggerTo(
          slideItems,
          0.2,
          {
            //delay: this.slideDelay,
            //y: 100,
            autoAlpha: 0
          },
          0,
          slide.id + "+=" + this.slideDelay
        )
        .to(slide, 0.2, { autoAlpha: 0 }, slide.id + "leave")
        .addCallback(this.bannerUpdate, slide.id, [tl, this]);
    });

    this.mainTimeLine = tl;
  },

  sliderNavigation() {
    this.sliderNavs.forEach(nav => {
      nav.addEventListener("click", e => {
        e.preventDefault();
        this.mainTimeLine.play()
        $('html,body').animate({scrollTop: $(this.selectionArea).offset().top - 200})

        let currentLabel = this.mainTimeLine.currentLabel(),
          target = nav.dataset.slide,
          timeOut = "",
          seekTo = () => {

            this.mainTimeLine.seek(target);
            //this.mainTimeLine.pause()
            setTimeout(() => {
              this.mainTimeLine.pause()
            }, 200)
          };
        if (currentLabel === target) return;

        clearTimeout(timeOut);
        this.mainTimeLine.seek(currentLabel + "+=" + this.slideDelay);

        //this.mainTimeLine.seek(target)
        timeOut = setTimeout(seekTo, 200);
      });
    });
  },

  bannerUpdate(tl, bannerObj) {
    let label = tl.currentLabel();
    bannerObj.sliderNavs.forEach(nav => {
      nav.classList.remove("active");
      if (nav.dataset.slide === label) {
        nav.classList.add("active");
      }
    });
  }

  // resize () {

  // 	if (this.mainTimeLine){
  // 		this.mainTimeLine.kill(null)
  // 	}
  // }
};
