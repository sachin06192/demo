export default {
	// Updation
    updateHtml() {
      DCObject.updateCircleProgress()
      DCObject.updateCollegeCostRelatedHtmls()
      DCObject.infoHtmlUpdates()
      DCObject.topBoxInfoHtmlUpdates()
      DCObject.$idealSavingSpan.html(DCObject.idealSavings.formatMoney(0))
      //DCObject.$savingsTotalMonthlySpan.html(DCObject.savingsMonthlyValue.formatMoney(0))
      let deficit = DCObject.totalDeficit

      if (DCObject.investment === "partially") {
        DCObject.$savingsPercentageSpan.html(DCObject.savingsPartialPercentage + '%')
      } else {
        DCObject.$savingsPercentageSpan.html('100%')
      }

      deficit = deficit <= 0 ? deficit * -1 :  deficit
      
      DCObject.$totalSavingsSpan.html(DCObject.totalSavings.formatMoney(0))
      DCObject.$totalDeficitSpan.html(deficit.formatMoney(0))

      
      
      if(DCObject.totalDeficit > 0) {
        $('.progress-info .total-deficit').removeClass('text-success')
        $('.progress-info .total-deficit').addClass('text-danger')
        DCObject.$detailedCalculator.find('.surplus-gap-title').html('Gap')
        DCObject.$detailedCalculator.find('.total-deficit-summary').html(DCObject.totalDeficit.formatMoney(0))
      } else {
        $('.progress-info .total-deficit').removeClass('text-danger')
        $('.progress-info .total-deficit').addClass('text-success')
        DCObject.$detailedCalculator.find('.surplus-gap-title').html('Surplus')
        DCObject.$detailedCalculator.find('.total-deficit-summary').html('$ 0')
      }
      DCObject.$fundingTotalSpan.html(DCObject.totalDeficit.formatMoney(0))
      DCObject.$monthlyContributionTotalSpan.html(parseInt(DCObject.monthlyContributionAmount).formatMoney(0))
      DCObject.$oneTimeInvestmentSpan.html(parseInt(DCObject.resultOptions.initialInvestment).formatMoney(0))
      DCObject.$inflamationPercentSpan.html(DCObject.resultOptions.annualInflation*100 +'%') 
      DCObject.$annualGrowthPercentSpan.html(DCObject.resultOptions.annualGrowthRate*100 +'%')
      DCObject.$detailedCalculator.find('.college-start-differ').html(18 - DCObject.resultOptions.age)

      if (DCObject.collegeCategory === "state-public"){
        DCObject.$inOutStateSpan.html('in state')
      } else if(DCObject.collegeCategory === "outofstate-public") {
        DCObject.$inOutStateSpan.html('out of state')
      }

    },
    updateCircleProgress() {
      let progressHolder = this.$circleProgressHolder,
        progressValue = progressHolder.find('.progress-value'),
        progressOverlay = progressHolder.find('.progress-circular__overlay')
       
      this.totalSavingsPercent = this.totalSavingsPercent > 100 ? 100 : Math.floor(this.totalSavingsPercent)
      progressValue.html(this.totalSavingsPercent+'%')
      TweenLite.to(progressOverlay, 0.5, { drawSVG: `0% ${this.totalSavingsPercent - 2}%` })
    },
    updateCollegeCostRelatedHtmls() {
      DCObject.$universitySpan.html(DCObject.resultOptions.collegeName)
      DCObject.$collegeStartYearSpan.html(DCObject.resultOptions.collegeStartYear)
      

      if(DCObject.collegeTotalCostWithoutExpenses !== 0 && DCObject.collegeTotalCost !== 0){
         //DCObject.$totalCollegeCostSpan.html(parseInt(DCObject.collegeTotalCostWithoutExpenses).formatMoney(0))
         DCObject.$additionalCostSpan.html(parseInt(DCObject.collegeTotalCost - DCObject.collegeTotalCostWithoutExpenses).formatMoney(0))
      }
      
    },
    infoHtmlUpdates() {
        let contributionDiffer = DCObject.initialMonthlyContribution - DCObject.monthlyContributionAmount,
            percentDiffer = 100 - DCObject.totalSavingsPercent
         
         //console.log(contributionDiffer)
        if(contributionDiffer <= 0) {
          DCObject.$monthlySaveSpan.html(`$ 0/month`)
          DCObject.$monthlyContributionMessageSpan.html("The current monthly contribution will cover your funding goal!")
        } else {
          DCObject.$monthlySaveSpan.html(`$ ${contributionDiffer}/month`)
          DCObject.$monthlyContributionMessageSpan.html(`You'll need to increase your monthly contribution to <span class="bold">$${DCObject.initialMonthlyContribution}</span>` +
           ` in order to make your college savings goal.`)

          //of <span class="bold">${DCObject.idealSavings.formatMoney(0)}</span>
        }
    },
    topBoxInfoHtmlUpdates() {
          let collegeCat = DCObject.collegeCategory === "state-public" ? 'in state' : 'out of state',
              collegeCost = DCObject.additionalExpense === "yes" ? Math.ceil(DCObject.collegeTotalCost) : DCObject.collegeTotalCostWithoutExpenses,
              partialPercent = DCObject.investment === "partially" ? DCObject.savingsPartialPercentage * 100 : '100',
              childAge = DCObject.resultOptions.age > 1 ? DCObject.resultOptions.age + " years" : DCObject.resultOptions.age + " year",
              deficit = DCObject.totalDeficit,
              surplusOrGap = ""

        deficit = deficit <= 0 ? deficit * -1 :  deficit
        surplusOrGap = DCObject.totalDeficit <= 0 ? "Surplus" : "Gap"
        
        if(DCObject.resultOptions.collegeName){
          DCObject.$infoYourGoal.find('.info').html(`Your child is <span class="bold">${childAge}</span>` +
            ` old and you selected <span class="bold">${DCObject.resultOptions.collegeName}</span>`)
          DCObject.$infoYourGoal.find('.info-bottom').html(`Years until college:&nbsp;&nbsp;<span class="bold">${18 - DCObject.resultOptions.age}</span><br/>` +
            `Total ${collegeCat} cost:&nbsp;&nbsp;<span class="bold">${parseInt(collegeCost).formatMoney(0)}</span>`)
          DCObject.$totalCollegeCostSpan.html(collegeCost.formatMoney(0))
        }

        if(DCObject.showYourNumbersSummary){
          DCObject.$infoYourNumber.find('.info').html(`You are funding <span class="bold">${partialPercent}%</span>`+
            ` (${DCObject.idealSavings.formatMoney(0)})`)
          DCObject.$infoYourNumber.find('.info-bottom').html(`One-time investment:&nbsp;&nbsp;<span class="bold">${parseInt(DCObject.resultOptions.initialInvestment).formatMoney(0)}</span><br/>` +
            `Suggested monthly contribution:&nbsp;&nbsp;<span class="bold">${parseInt(DCObject.initialMonthlyContribution).formatMoney(0)}</span>`)
          DCObject.$detailedCalculator.find('.total-fund-percent').html(`${partialPercent}%`)
          DCObject.$detailedCalculator.find('.total-savings-percent').html(`${DCObject.totalSavingsPercent}%`)
        }

        if(DCObject.showReviewSummary){
          DCObject.$infoYourSummary.find('.info').html(`Your funding goal&nbsp;&nbsp;<span class="bold">${DCObject.idealSavings.formatMoney(0)}</span>`)
          DCObject.$infoYourSummary.find('.info-bottom').html(`You will save:&nbsp;&nbsp;<span class="bold">${DCObject.totalSavings.formatMoney(0)}</span><br/>` +
            `${surplusOrGap}:&nbsp;&nbsp;<span class="bold">${deficit.formatMoney(0)}</span>`)
        }
    },
    _circleProgressInit() {
      let progressHolder = this.$circleProgressHolder,
        progressOverlay = progressHolder.find('.progress-circular__overlay')

      TweenLite.set(progressOverlay, { drawSVG: "0% 0%", rotation: -90, transformOrigin: "50% 50%" })
    }
}