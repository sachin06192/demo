export default {
  // binding events
  _eventListeners() {
    // Next Button
    this.$nextBtn.click(this.stepNext)
    // Prev Button
    this.$prevBtn.click(this.stepPrev)
    // Inner next
    this.$nextBtnInner.click(this.stepNextInner)
    // Inner prev
    this.$prevBtnInner.click(this.stepPrevInner)
    //gender
    this.$genderOption.on('change', this.genderHandler)
    // CollegeCategory
    //this.$collegeCategoryOption.on('change', this.collegeCategoryHandler)
    this.$collegeCategoryChangeButton.on('change', this.collegeCategoryHandler)
    // Additional expense change
    this.$additionalExpenseChooser.on('change', this.additionalExpenseHandler)
    // student age
    this.$ageOption.on('change', this.ageHandler)
    //Savings percentage
    this.$savingsPercentageOption.on('change', this.savingsPercentageHandler)
    //House hold incom input
    this.$houseHoldInput.on('change', this.houseHoldInputHandler)
    //Monthly expense savings input
    this.$monthlyExpenseInput.on('change', this.monthlyExpenseHandler)
    // Inflation change
    this.$annualInflationOption.on('change', this.inflationChangeHandler)
    // Annual Growth change
    this.$annualGrowthOption.on('change', this.annualGrowthChangeHandler)
    // Monthly contriution
    this.$monthlyContributionInput.on('keydown change', this.monthlyContributionHandler)
    // only number vcalidator
    this.$houseHoldInput.on('keypress', this.onlyNumber)
    this.$monthlyExpenseInput.on('keypress', this.onlyNumber)
    // Invest changer tab
    this.$investChangerButton.on('click', this.investPlanHandler)
    // useredit
    this.$userEditTrigger.on('click', this.userEditButtonHandler)
    // Review plan btn
    this.$reviewPlanBtn.on('click', this.reviewSummaryHandler)

    // One time investment input
    this.$oneTimeInvestmentInput.on('keydown', this.oneTimeInvestmentHandler)

    // Reset handler
    this.$resetButton.on('click', this.resetFunction)

    // Tab event listener
    this.$tabLinks.on('click', this.tabLinksHandler)
  }
}
