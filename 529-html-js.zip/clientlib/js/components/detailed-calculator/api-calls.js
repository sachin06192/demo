import { getQucikResults } from "../getquickresults"
import {DCObject} from "./index"

export default {
  _collegeSelect() {

      DCObject.$collegeOption.select2({
        ajax: {
          url: 'https://www.americanfunds.com/advisor/investments//cscapi/findschoolsfrompage',
          dataType: 'json',
          delay: 250,
          method: "POST",
          data: function(params) {
            return {
              Name: params.term, // search term
              Page: params.page || 0,
              IncludeRoomAndBoard: true,
              CurrentCollegeName: "2018 National Public Averages",
              SortDirection: "ascending",
              TableType: ""
            }
          },
          processResults: function(data, params) {
            params.page = params.page || 0;
            let currentPageNumber = $(data.html).find('.action-paging-button.selected').data('pagenumber')
            let lastPageNumber = $(data.html).find('.action-next-button').prev().data('pagenumber')

            return {
              results: DCObject.getCGCollegeData(data.html),
              pagination: {
                more: (params.page * 10) < 10 * lastPageNumber
              }
            };
          },
          cache: true

        },
        //placeholder: 'Searchy',
        escapeMarkup: function(markup) { return markup; }, // let our custom formatter work
        minimumInputLength: 1,
        templateResult: DCObject.formatRepo,
        templateSelection: DCObject.formatRepoSelection
      });
    },
    formatRepo(repo) {
      if (repo.loading) {
        return "Searching...";
      }
      var markup = "<div class='select2-result-repository clearfix'>" +
        "<div class='select2-result-repository__meta'>" +
        "<div class='select2-result-repository__title'>" + repo.name + "</div></div></div>"

      return markup;
    },
    formatRepoSelection(repo) {
      //return repo.full_name || repo.text;
      DCObject.resultOptions.collegeName = repo.name
      DCObject.resultOptions.institutionID = repo.id.split('_')[1]
      DCObject.resultOptions.contributionAmount = 0
      if (DCObject.collegeCategory === "state-public") {
        if (DCObject.additionalExpense === 'yes') {
          DCObject.resultOptions.currentAnnualCost = repo.inStateWithCosts
        } else {
          DCObject.resultOptions.currentAnnualCost = repo.inStateWithoutCosts
        }
      } else if (DCObject.collegeCategory === "outofstate-public") {
        if (DCObject.additionalExpense === 'yes') {
          DCObject.resultOptions.currentAnnualCost = repo.outStateWithCosts
        } else {
          DCObject.resultOptions.currentAnnualCost = repo.outStateWithoutCosts
        }
      } else if (DCObject.collegeCategory === "private") {
        DCObject.resultOptions.currentAnnualCost = repo.inStateWithCosts
      }
      DCObject.collegeInStateFees = repo.inStateWithCosts
      DCObject.collegeInStateFeesWithoutCost = repo.inStateWithoutCosts
      DCObject.collegeOutStateFees = repo.outStateWithCosts
      DCObject.collegeOutStateFeesWithoutCost = repo.outStateWithoutCosts



      DCObject.callQuickResults(function(data) {
        if (DCObject.$additionalControlSpan.hasClass = "disabled") {
          DCObject.$additionalControlSpan.removeClass('disabled')
        }
        DCObject.updateMonthlyContribution(data)
        DCObject.$bottomActions.show()
      })

      //DCObject.idealSavings = repo.outStateWithCosts
      //DCObject.savingsMonthlyValue = DCObject.idealSavings / 48
      //DCObject.partialSavings = DCObject.idealSavings * parseInt(DCObject.savingsPartialPercentage) / 100

      //DCObject.updateHtml()
      return repo.name
    },
    getCGCollegeData(response) {
      // prepare HTMLs from the response so that its easier to grab the values
      //console.log(response)

      $('body').append('<div id="cg-jsonHolder" style="display:none"></div>');
      $('#cg-jsonHolder').append(response);
      $('#cg-jsonHolder tbody tr td:first-child p:first-child').addClass('cg-college-name');

      var colleges = [];
      $('#cg-jsonHolder tbody tr').each(function(i, elem) {
        colleges.push({
          id: $(elem).attr("id"),
          name: $(elem).find('.cg-college-name').text(),
          outStateWithCosts: Math.round($(elem).data('outstatewithcosts')),
          outStateWithoutCosts: Math.round($(elem).data('outstatewithoutcosts')),
          inStateWithCosts: Math.round($(elem).data('instatewithcosts')),
          inStateWithoutCosts: Math.round($(elem).data('instatewithoutcosts'))
        });
      });
      $('#cg-jsonHolder').remove(); // remove the markups once the job is done

      return colleges;
    },
    // Quick result
    callQuickResults(cbFunc, noSpread) {
      if (DCObject.resultOptions.collegeName === "") {
        return
      }
      this.$bottomActions.addClass('disabled')
      getQucikResults(DCObject.resultOptions, (data) => {
        if (typeof cbFunc === "function") {
          cbFunc(data)
        }
        if (noSpread) {
          DCObject.updateHtml()
          this.$bottomActions.removeClass('disabled')
          return
        }
        if (this.investment === "partially") {
          DCObject.idealSavings = data.chartData.TotalCostToFund
          //DCObject.totalSavingsPercent = DCObject.calcPercent(data.chartData.TotalCostToFund, data.chartData.TotalSavings)
          DCObject.totalSavingsPercent = DCObject.calcPercent(data.chartData.TotalCost, data.chartData.TotalSavings)
          //DCObject.totalDeficit = data.chartData.TotalCostToFund - data.chartData.TotalSavings
          DCObject.totalDeficit = data.chartData.TotalCost - data.chartData.TotalSavings
        } else {
          DCObject.idealSavings = data.chartData.TotalCost
          DCObject.totalSavingsPercent = DCObject.calcPercent(data.chartData.TotalCost, data.chartData.TotalSavings)
          DCObject.totalDeficit = data.chartData.TotalCost - data.chartData.TotalSavings

        }

        //DCObject.savingsMonthlyValue = data.chartData.RequiredContribution
        DCObject.totalSavings = data.chartData.TotalSavings

        if (DCObject.additionalExpense === "yes") {
          DCObject.collegeTotalCost = data.chartData.TotalCost
          DCObject.collegeTotalCostWithoutExpenses = 0

        } else {
          DCObject.collegeTotalCostWithoutExpenses = data.chartData.TotalCost
          DCObject.collegeTotalCost = 0
        }



        DCObject.updateHtml()
        this.$bottomActions.removeClass('disabled')
      })

    }
}
