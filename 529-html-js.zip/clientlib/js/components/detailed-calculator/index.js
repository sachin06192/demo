import apiCalls from './api-calls'
import utilities from './utilities'
import htmlUpdation from './htmlupdation'
import handlers from './handlers'
import eventListeners from './eventlistners'

(function(window) {

  'use strict'
  let DCObject = ''
  //resultOptions = defaultOptions
  function DetailedCalculator() {
    this.$detailedCalculator = $('#main-detailed-calculator')
    this.$nextBtn = this.$detailedCalculator.find('.next')
    this.$prevBtn = this.$detailedCalculator.find('.previous')
    this.$nextBtnInner = this.$detailedCalculator.find('.inner-next')
    this.$prevBtnInner = this.$detailedCalculator.find('.inner-previous')
    this.$progressBarLi = this.$detailedCalculator.find('.progressbar li')
    this.$genderOption = this.$detailedCalculator.find('[name="genderOption"]')
    this.$collegeCategoryChangeButton = this.$detailedCalculator.find('[name="college-category-chooser"]')
    this.$ageOption = this.$detailedCalculator.find('[name="student-age"]')
    this.$savingsPercentageOption = this.$detailedCalculator.find('[name="savings-percentage-option"]')
    this.$additionalExpenseChooser = this.$detailedCalculator.find('[name="additional-expense-chooser"]')
    this.$savingsPercentageSpan = this.$detailedCalculator.find('.savings-percentage-span')
    this.$collegeOption = this.$detailedCalculator.find('#college-option')
    this.$idealSavingSpan = this.$detailedCalculator.find('.ideal-savings-amount')
    this.$savingsTotalMonthlySpan = this.$detailedCalculator.find('#savings-total-monthly')
    this.$houseHoldInput = this.$detailedCalculator.find('#house-hold-input')
    this.$monthlyExpenseInput = this.$detailedCalculator.find('#monthly-expense-input')
    this.$monthlyContributionInput = this.$detailedCalculator.find('#monthly-contribution-input')
    this.$oneTimeInvestmentInput = this.$detailedCalculator.find('#one-time-investment-input')
    this.$monthlySaveSpan = this.$detailedCalculator.find('.monthly-save')
    this.$investChangerButton = this.$detailedCalculator.find('.invest-changer')
    this.$annualInflationOption = this.$detailedCalculator.find('#annual-inflation-option')
    this.$annualGrowthOption = this.$detailedCalculator.find('#annual-growth-option')
    this.$totalSavingsSpan = this.$detailedCalculator.find('.total-savings')
    this.$totalDeficitSpan = this.$detailedCalculator.find('.total-deficit')
    this.$monthlyContributionTotalSpan = this.$detailedCalculator.find('.monthly-contribution-total')
    this.$oneTimeInvestmentSpan = this.$detailedCalculator.find('.total-onetime-investment')
    this.$fundingTotalSpan = this.$detailedCalculator.find('.funding-total')
    this.$userEditTrigger = this.$detailedCalculator.find('.user-edit-trigger')
    this.$tabLinks = this.$detailedCalculator.find('.tab-link>a')
    this.$percentageToggler = this.$detailedCalculator.find('#percentage-toggler-wrapper')
    this.$percentageFullSpan = this.$detailedCalculator.find('#percentage-full-wrapper')
    this.$planBannerTitle = $('#plan-banner-title')
    this.$additionalControlSpan = this.$detailedCalculator.find('.addition-control-div')
    this.$bottomActions = this.$detailedCalculator.find('.bottom-action')
    this.$circleProgressHolder = this.$detailedCalculator.find('.circle-progress-holder')
    this.$totalCollegeCostSpan = this.$detailedCalculator.find('.total-college-cost')
    this.$additionalCostSpan = this.$detailedCalculator.find('.additional-cost')
    this.$inOutStateSpan = this.$detailedCalculator.find('.in-out-state')
    this.$universitySpan = this.$detailedCalculator.find('.university')
    this.$collegeStartYearSpan = this.$detailedCalculator.find('.college-start-year')
    this.$monthlyContributionMessageSpan = this.$detailedCalculator.find('.monthly-contribution-span')
    this.$bottomActions = this.$detailedCalculator.find('.bottom-action')
    this.$reviewPlanBtn = this.$detailedCalculator.find('.review-btn')
    this.$inflamationPercentSpan = this.$detailedCalculator.find('.inflamation-percent-span')
    this.$annualGrowthPercentSpan = this.$detailedCalculator.find('.annual-growth-percent-span')
    this.$infoYourGoal = this.$detailedCalculator.find('.info-box.your-goal')
    this.$infoYourNumber = this.$detailedCalculator.find('.info-box.your-number')
    this.$infoYourSummary = this.$detailedCalculator.find('.info-box.your-summary')
    this.$resetButton = this.$detailedCalculator.find('.reset-button')

    this.current_fs = null
    this.next_fs = null
    this.previous_fs = null
    this.savingsPartialPercentage = this.$savingsPercentageOption.val()

    this.formError = false
    // details
    this.gender = ""
    this.resultOptions = {
      age: 0,
      annualGrowthRate: this.$annualGrowthOption.val(),
      annualInflation: this.$annualInflationOption.val(),
      collegeDuration: 4,
      collegeStartAge: 18,
      collegeStartYear: new Date().getFullYear() + 18,
      currentAnnualCost: 0,
      collegeName: "",
      contributionType: "Monthly",
      contributionAmount: 0,
      initialInvestment: this.$oneTimeInvestmentInput.val(),
      institutionID: null,
      percentToCover: 1,
      includeContributionIncrease: false,
      stepAmount: 0,
      stepStartDate: "2018.1",
      imageWidth: 306
    }
    this.collegeInStateFees = 0
    this.collegeInStateFeesWithoutCost = 0
    this.collegeOutStateFees = 0
    this.collegeOutStateFeesWithoutCost = 0
    this.collegeCategory = this.$collegeCategoryChangeButton.val()
    this.additionalExpense = this.$additionalExpenseChooser.val()
    //this.monthlySave = 0,
    //this.userMonthlySave = 0,
    this.monthlyContributionAmount = this.$monthlyContributionInput.val()
    this.initialMonthlyContribution = 0
    this.monthlyContributionTotal = 0
    this.idealSavings = 0
    //this.savingsMonthlyValue = 0
    this.partialSavings = 0
    this.investment = "fully"
    this.totalSavings = 0
    this.totalDeficit = 0
    this.totalSavingsPercent = 0
    this.collegeTotalCost = 0
    this.collegeTotalCostWithoutExpenses = 0
    this.delayedApiCall = null

    this.showYourNumbersSummary = false
    this.showReviewSummary = false
    // Intitialize
    this._init()
  }

  DetailedCalculator.prototype = {
    _init() {
      DCObject = this
      this.$percentageToggler.hide()
      this._eventListeners()
      this._collegeSelect()
      this._circleProgressInit()
      //this._calculateMonthlySave()
      this.$bottomActions.hide()



    },
    ...apiCalls,
    ...utilities,
    ...htmlUpdation,
    ...handlers,
    ...eventListeners
}

new DetailedCalculator() // Calling new instance

})(window)
