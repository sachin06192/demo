export default {
  calcPercent(num, per) {
    return (per / num) * 100
  },
  // validators
  validate() {
    return DCObject.collegeName !== ""
  },
  onlyNumber(evt) {
    evt = (evt) ? evt : window.event;
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;
  },
  // Calculations
  calculateTax(num) {
    return (num <= 13350) ? num * .1 :
      (num <= 50800) ? (13350 * .1) + (num - 13350) * .15 :
      (num <= 131200) ? (13350 * .1) + (50800 - 13350) * .15 + (num - 50800) * .25 :
      (num <= 212500) ? (13350 * .1) + (50800 - 13350) * .15 + (131200 - 50800) * .25 +
      (num - 131200) * .28 :
      (num <= 416700) ? (13350 * .1) + (50800 - 13350) * .15 + (131200 - 50800) * .25 +
      (212500 - 131200) * .28 + (num - 212500) * .33 :
      (num <= 444550) ? (13350 * .1) + (50800 - 13350) * .15 + (131200 - 50800) * .25 +
      (212500 - 131200) * .28 + (416700 - 212500) * .33 + (num - 416700) * .35 :
      (13350 * .1) + (50800 - 13350) * .15 + (131200 - 50800) * .25 + (212500 - 131200) * .28 +
      (416700 - 212500) * .33 + (444550 - 416700) * .35 + (num - 444550) * .396;
  },
  // _calculateMonthlySave(){
  //   if(DCObject.resultOptions.collegeName === ""){
  //     return
  //   } 
  //   let houseHoldVal = this.$houseHoldInput.val(),
  //       monthlyExpenseVal = this.$monthlyExpenseInput.val(),
  //       monthlySaveValue = null

  //       monthlySaveValue = (((houseHoldVal - DCObject.calculateTax(houseHoldVal)) - (monthlyExpenseVal * 12)) * .6)/12
  //       DCObject.userMonthlySave = monthlySaveValue || 0
  //       DCObject.resultOptions.contributionAmount = Math.round(DCObject.userMonthlySave)

  // },
  _calculateMonthlySave() {
    if (DCObject.resultOptions.collegeName === "") {
      return
    }
    DCObject.resultOptions.contributionAmount = DCObject.monthlyContributionAmount
  },
  _animateBannerText(target) {
    let currentTitle = DCObject.$planBannerTitle.find('>.title.active'),
      activeTitle = DCObject.$planBannerTitle.find('>.title[data-relate=' + target + ']')

    currentTitle.removeClass('active')
    activeTitle.addClass('active')

    let tl = new TimelineLite()
    tl.staggerTo($(currentTitle).find('>span'), 0.4, { y: -40, autoAlpha: 0 }, 0.1)
      .to(currentTitle, 0.4, { autoAlpha: 0, display: 'none' })
      .to(activeTitle, 0.4, { autoAlpha: 1, display: 'block', overwrite: 'all' }, 'reveal')
      .staggerFromTo(activeTitle.find('>span'), 0.4, { y: 40, autoAlpha: 0, overwrite: 'all' }, { y: 0, autoAlpha: 1, overwrite: 'all' }, 0.1, 'reveal')

  }
}
