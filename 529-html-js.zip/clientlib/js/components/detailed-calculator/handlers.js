export default {
  genderHandler() {
    DCObject.gender = this.value
  },
  collegeCategoryHandler() {
    DCObject.collegeCategory = this.value
    if (DCObject.additionalExpense === 'yes') {
      if (DCObject.collegeCategory === "state-public") {
        DCObject.resultOptions.currentAnnualCost = DCObject.collegeInStateFees
      } else if (DCObject.collegeCategory === "outofstate-public") {
        DCObject.resultOptions.currentAnnualCost = DCObject.collegeOutStateFees
      }
    } else {
      if (DCObject.collegeCategory === "state-public") {
        DCObject.resultOptions.currentAnnualCost = DCObject.collegeInStateFeesWithoutCost
      } else if (DCObject.collegeCategory === "outofstate-public") {
        DCObject.resultOptions.currentAnnualCost = DCObject.collegeOutStateFeesWithoutCost
      }
    }

    DCObject.callQuickResults(function(data) {
      DCObject.updateMonthlyContribution(data)
    })
  },

  additionalExpenseHandler() {
    DCObject.additionalExpense = this.value


    if (DCObject.additionalExpense === 'yes') {
      if (DCObject.collegeCategory === "state-public") {
        DCObject.resultOptions.currentAnnualCost = DCObject.collegeInStateFees
      } else if (DCObject.collegeCategory === "outofstate-public") {
        DCObject.resultOptions.currentAnnualCost = DCObject.collegeOutStateFees
      }
    } else {
      if (DCObject.collegeCategory === "state-public") {
        DCObject.resultOptions.currentAnnualCost = DCObject.collegeInStateFeesWithoutCost
      } else if (DCObject.collegeCategory === "outofstate-public") {
        DCObject.resultOptions.currentAnnualCost = DCObject.collegeOutStateFeesWithoutCost
      }
    }

    if (DCObject.resultOptions.collegeName !== "") {
      DCObject.callQuickResults(function(data) {
        DCObject.updateMonthlyContribution(data)
      })
    }
  },

  ageHandler() {
    DCObject.resultOptions.age = this.value
    DCObject.resultOptions.collegeStartYear = new Date().getFullYear() + 18 - parseInt(DCObject.resultOptions.age)
    DCObject.resultOptions.contributionAmount = 0
    if (DCObject.resultOptions.collegeName !== "") {
      DCObject.callQuickResults()
    }
  },
  savingsPercentageHandler() {
    DCObject.savingsPartialPercentage = this.value
    DCObject.resultOptions.percentToCover = DCObject.savingsPartialPercentage
    DCObject.callQuickResults(function(data) {
      DCObject.updateMonthlyContribution(data)
    })
  },

  houseHoldInputHandler() {
    DCObject._calculateMonthlySave()
    DCObject.callQuickResults()

  },

  inflationChangeHandler() {
    DCObject.resultOptions.annualInflation = this.value
    DCObject.callQuickResults(function(data) {
      DCObject.updateMonthlyContribution(data)
    })
  },

  annualGrowthChangeHandler() {
    DCObject.resultOptions.annualGrowthRate = this.value
    DCObject.callQuickResults()
  },

  monthlyExpenseHandler() {
    DCObject._calculateMonthlySave()
    DCObject.callQuickResults()
  },
  investPlanHandler() {
    DCObject.$investChangerButton.removeClass('active')
    $(this).addClass('active')
    if ($(this).data('invest-format') === "partially") {
      DCObject.investment = "partially"
      DCObject.resultOptions.contributionAmount = 0
      DCObject.resultOptions.percentToCover = DCObject.savingsPartialPercentage
      DCObject.$percentageFullSpan.hide()
      DCObject.$percentageToggler.show()

    } else {
      DCObject.resultOptions.percentToCover = 1
      DCObject.resultOptions.contributionAmount = 0
      DCObject.investment = "fully"
      DCObject.$percentageToggler.hide()
      DCObject.$percentageFullSpan.show()
    }

    DCObject.callQuickResults(function(data) {
      DCObject.updateMonthlyContribution(data)
    })
  },

  updateMonthlyContribution(data) {
    DCObject.monthlyContributionAmount = Math.ceil(data.chartData.RequiredContribution)
    DCObject.$monthlyContributionInput.val(DCObject.monthlyContributionAmount)
    DCObject.initialMonthlyContribution = Math.ceil(data.chartData.RequiredContribution)


  },

  monthlyContributionHandler() {
    clearTimeout(DCObject.delayedApiCall)
    if (isNaN(this.value)) {
      return
    }

    let input = this


    DCObject.delayedApiCall = setTimeout(function() {

      DCObject.monthlyContributionAmount = input.value

      DCObject.resultOptions.contributionAmount = DCObject.monthlyContributionAmount
      DCObject.callQuickResults()
    }, 800)

  },
  oneTimeInvestmentHandler() {
    clearTimeout(DCObject.delayedApiCall)
    let input = this
    DCObject.delayedApiCall = setTimeout(function() {
      DCObject.resultOptions.initialInvestment = input.value
      DCObject.callQuickResults()
    }, 800)
  },

  userEditButtonHandler() {
    DCObject._calculateMonthlySave()
    DCObject.showYourNumbersSummary = true
    DCObject.callQuickResults()
  },

  reviewSummaryHandler() {
    let resultOptionPrevState = $.extend({}, DCObject.resultOptions)
    DCObject.showReviewSummary = true
    if (DCObject.additionalExpense === 'no') {

      if (DCObject.collegeCategory === "state-public") {
        DCObject.resultOptions.currentAnnualCost = DCObject.collegeInStateFees
      } else if (DCObject.collegeCategory === "outofstate-public") {
        DCObject.resultOptions.currentAnnualCost = DCObject.collegeOutStateFees
      }
      DCObject.callQuickResults((data) => {
        DCObject.collegeTotalCost = data.chartData.TotalCost
        DCObject.resultOptions = resultOptionPrevState
      }, true)

    } else {
      if (DCObject.collegeCategory === "state-public") {
        DCObject.resultOptions.currentAnnualCost = DCObject.collegeInStateFeesWithoutCost
      } else if (DCObject.collegeCategory === "outofstate-public") {
        DCObject.resultOptions.currentAnnualCost = DCObject.collegeOutStateFeesWithoutCost
      }
      DCObject.callQuickResults((data) => {
        DCObject.collegeTotalCostWithoutExpenses = data.chartData.TotalCost
        //console.log(DCObject.collegeTotalCost + ' ' + DCObject.collegeTotalCostWithoutExpenses)
        DCObject.resultOptions = resultOptionPrevState
      }, true)
    }

  },

  tabLinksHandler() {

    let target = this.href.split('#')[1]
    DCObject._animateBannerText(target)
    if ($(this).hasClass('active') || target === "savings-summary") return
    // if(target === 'your-numbers' || target === 'your-goal')
    // {
    //  DCObject.resultOptions.contributionAmount = 0 
    // }

    DCObject.resultOptions.contributionAmount = 0
    if (target === 'your-plan') {
      DCObject.userEditButtonHandler()
    }
    DCObject.callQuickResults()
  },

  // Tab travel to first step
  resetToFirst() {
    DCObject.$detailedCalculator.find('.tab-contents>.step').removeClass('active')
    DCObject.$detailedCalculator.find('.progressbar > li').removeClass('active completed')

    DCObject.$detailedCalculator.find('.tab-contents>.step:nth-child(1)').addClass('active')
    DCObject.$detailedCalculator.find('.progressbar > li:nth-child(1)').addClass('active')
    DCObject.$detailedCalculator.find('.info-box .info, .info-box .info-bottom').html('')
    DCObject.$detailedCalculator.find('.progressbar > li:nth-child(1) .info-box .info').html('Please select your funding goals')

  },

  // go to first step
  gotToFirstStep() {
    DCObject.$detailedCalculator.find('.tab-contents>.step').removeClass('active')
    DCObject.$detailedCalculator.find('.progressbar > li').removeClass('active completed')

    DCObject.$detailedCalculator.find('.tab-contents>.step:nth-child(1)').addClass('active')
    DCObject.$detailedCalculator.find('.progressbar > li:nth-child(1)').addClass('active')
  },

  // Reset action
  resetFunction(e) {
    e.preventDefault()
    $('html, body').animate({ scrollTop: DCObject.$detailedCalculator.offset().top - 100 })

    DCObject.$annualInflationOption.val(0.04).trigger('change')
    DCObject.$annualGrowthOption.val(0.08).trigger('change')
    DCObject.$ageOption.val(0).trigger('change')
    DCObject.$detailedCalculator.find('#instate-radio').attr('checked', true).trigger('click')
    DCObject.$detailedCalculator.find('#additional-expense-yes-radio').attr('checked', true).trigger('click')
    DCObject.$savingsPercentageOption.val(0.5).trigger('change')
    DCObject.$monthlyContributionInput.val(0).trigger('change')
    DCObject.$detailedCalculator.find('.invest-changer[data-invest-format="fully"]').trigger('click')
    DCObject.$collegeOption.val('').trigger('change')

    DCObject.resultOptions = {
      age: 0,
      annualGrowthRate: DCObject.$annualGrowthOption.val(),
      annualInflation: DCObject.$annualInflationOption.val(),
      collegeDuration: 4,
      collegeStartAge: 18,
      collegeStartYear: new Date().getFullYear() + 18,
      currentAnnualCost: 0,
      collegeName: "",
      contributionType: "Monthly",
      contributionAmount: 0,
      initialInvestment: DCObject.$oneTimeInvestmentInput.val(),
      institutionID: null,
      percentToCover: 1,
      includeContributionIncrease: false,
      stepAmount: 0,
      stepStartDate: "2018.1",
      imageWidth: 306
    }
    DCObject.savingsPartialPercentage = DCObject.$savingsPercentageOption.val()
    DCObject.formError = false
    DCObject.collegeInStateFees = 0
    DCObject.collegeInStateFeesWithoutCost = 0
    DCObject.collegeOutStateFees = 0
    DCObject.collegeOutStateFeesWithoutCost = 0
    DCObject.collegeCategory = DCObject.$collegeCategoryChangeButton.val()
    DCObject.additionalExpense = DCObject.$additionalExpenseChooser.val()
    //this.monthlySave = 0,
    //this.userMonthlySave = 0,
    DCObject.monthlyContributionAmount = DCObject.$monthlyContributionInput.val()
    DCObject.initialMonthlyContribution = 0
    DCObject.monthlyContributionTotal = 0
    DCObject.idealSavings = 0
    //this.savingsMonthlyValue = 0
    DCObject.partialSavings = 0
    DCObject.investment = "fully"
    DCObject.totalSavings = 0
    DCObject.totalDeficit = 0
    DCObject.totalSavingsPercent = 0
    DCObject.collegeTotalCost = 0
    DCObject.collegeTotalCostWithoutExpenses = 0
    DCObject.delayedApiCall = null

    DCObject.showYourNumbersSummary = false
    DCObject.showReviewSummary = false




    DCObject.$additionalControlSpan.addClass('disabled')
    DCObject.$bottomActions.hide()
    DCObject.resetToFirst()

  },
  // Navigation handlers
  //next
  stepNext(e) {
    e.preventDefault()
    $('html, body').animate({ scrollTop: DCObject.$detailedCalculator.offset().top - 100 })
    DCObject.formError = false
    if (!DCObject.validate()) {
      DCObject.formError = true
      return
    }
    DCObject.current_fs = $(this).closest('.step');

    DCObject.next_fs = $(this).closest('.step').next();
    DCObject.previous_fs = $(this).closest('.step').prev();

    //activate next step on progressbar using the index of next_fs
    DCObject.$progressBarLi.eq($(".step").index(DCObject.next_fs)).addClass("active");
    DCObject.$progressBarLi.eq($(".step").index(DCObject.current_fs)).removeClass("active");
    DCObject.$progressBarLi.eq($(".step").index(DCObject.current_fs)).addClass("completed");

    //show the next fieldset
    DCObject.next_fs.addClass('active');
    DCObject.current_fs.removeClass('active');



    //DCObject._animateBannerText(DCObject.next_fs.attr('id'))

    if ($(this).data('calculate') === false) {

      return
    }

    if (!$(this).hasClass('user-edit-trigger')) {
      DCObject.resultOptions.contributionAmount = 0
      DCObject.callQuickResults()
    }

    $('html, body').animate({ scrollTop: DCObject.$detailedCalculator.offset().top - 100 })
  },
  //prev
  stepPrev(e) {
    e.preventDefault()
    $('html, body').animate({ scrollTop: DCObject.$detailedCalculator.offset().top - 100 })
    DCObject.current_fs = $(this).closest('.step');
    DCObject.previous_fs = $(this).closest('.step').prev();

    //de-activate current step on progressbar
    $(".progressbar li").eq($(".step").index(DCObject.current_fs)).removeClass("active");
    $(".progressbar li").eq($(".step").index(DCObject.current_fs)).removeClass("completed");
    $(".progressbar li").eq($(".step").index(DCObject.previous_fs)).addClass("active");

    //show the previous fieldset
    DCObject.current_fs.removeClass('active');
    DCObject.previous_fs.addClass('active');

    //DCObject._animateBannerText(DCObject.previous_fs.attr('id'))
    if ($(this).data('calculate') === false) {
      return
    }
    DCObject.resultOptions.contributionAmount = 0
    DCObject.callQuickResults()


  },
  //inner next
  stepNextInner() {
    DCObject.current_fs = $(this).closest('.inner-step');
    DCObject.next_fs = $(this).closest('.inner-step').next();

    //show the next fieldset
    DCObject.next_fs.addClass('active');
    DCObject.current_fs.removeClass('active');
  },
  //inner prev
  stepPrevInner() {
    DCObject.current_fs = $(this).closest('.inner-step');
    DCObject.previous_fs = $(this).closest('.inner-step').prev();

    //show the previous fieldset
    DCObject.current_fs.removeClass('active');
    DCObject.previous_fs.addClass('active');
  }
}
