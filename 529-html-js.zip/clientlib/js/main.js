import "nodelist-foreach-polyfill";
// slick slider
import "./components/slick-init";

// Selection tab
import { selectionTabs } from "./components/planselectiontab";

// Initialize custom option fields
import "./components/initCustomSelect";

// Progressbar
import "./components/progressbar";

// popup js
import "./components/popup";

// scroll js
import "./components/scroll";
// Site script
import siteScripts from "./components/sitescripts";
siteScripts.init();
window.onload = () => {
  if (select("#plan-selection-slider")) new selectionTabs();
};
import "./components/table";
import "./components/graphscript";
import "./components/graphscript-2";
import "./components/saveborrow";
import "./components/detailedcalculator";
import "./components/componentgraphs";
