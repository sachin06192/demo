(function(){ 
	function TopicSelection(elem){
        var tsWrap = elem;
        $(tsWrap).find('.cmp-topic-selection__checkbox').prop('checked', false);
    
        $(tsWrap).find('.cmp-topic-selection__button').off('click').on('click', function(){
            var $checkboxes = $(tsWrap).find('.cmp-topic-selection__checkbox'),
            options = [],
            redirectUrl = $(this).data('href');
    
            if(!$checkboxes.filter(':checked').length) return;
            $checkboxes.not(':last').filter(':checked').each(function(){
                options.push($(this).attr('name'));
            });
            redirectUrl += '?q=' + options.join('~');
            window.location.href = redirectUrl;
            return false;
        });
    
        $(tsWrap).find('.cmp-topic-selection__checkbox--select-all').off('click.selectAll').on('click.selectAll', function(){
            var isChecked = $(this)[0].checked,
            checkboxes = $(tsWrap).find('.cmp-topic-selection__checkbox').not(this);
            checkboxes.prop({
                disabled: isChecked,
                checked: isChecked
            });
        });
    
        $(tsWrap).find('label').off('click.setActive').on('click.setActive', function(e){
            e.preventDefault();
            e.stopPropagation();
            $(this).siblings('.cmp-topic-selection__checkbox').trigger('click');
        });
    
        $(tsWrap).find('.cmp-topic-selection__checkbox').off('click.setActive').on('click.setActive', function(e){
            var $button = $(tsWrap).find('button');
            if($(tsWrap).find('.cmp-topic-selection__checkbox').filter(":checked").length){
                $button.addClass('active');
            } else {
                $button.removeClass('active');
            }
        });
	}


    function topicInit() {
        var elements = document.getElementsByClassName("cmp-topic-selection");
        for (var i = 0; i < elements.length; i++) {
            new TopicSelection(elements[i]);
        }       
    }

    if (document.readyState !== "loading") {
        topicInit();
    } else {
        document.addEventListener("DOMContentLoaded", topicInit());
    }
})();

